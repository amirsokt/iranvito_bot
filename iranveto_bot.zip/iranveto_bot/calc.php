<?php
/**
 * ماشین‌حساب داخل چت (دکمه‌های شیشه‌ای) + محاسبه‌ی مقدار ارز: «3 دلار»، «0.5 بیتکوین»، «100 ین»
 */
declare(strict_types=1);

/* ---------- محاسبه امن عبارت (بدون eval) ---------- */
function calcEval(string $s): ?float {
  $s = rtrim($s, '+-*/'); if ($s === '') return null;
  $tok = []; $cur = ''; $len = strlen($s);
  for ($i = 0; $i < $len; $i++) {
    $ch = $s[$i];
    if (ctype_digit($ch) || $ch === '.') { $cur .= $ch; continue; }
    if ($ch === '%') { if ($cur === '' || $cur === '-' || substr($cur, -1) === '%') return null; $cur .= '%'; continue; }
    if (strpos('+-*/', $ch) === false) return null;
    if ($cur === '') {
      if ($ch === '-' && (!$tok || strpos('+-*/', (string) end($tok)) !== false)) { $cur = '-'; continue; }
      return null;
    }
    $tok[] = $cur; $cur = ''; $tok[] = $ch;
  }
  if ($cur !== '') $tok[] = $cur;
  $vals = []; $ops = []; $pcf = [];
  foreach ($tok as $i => $t) {
    if ($i % 2 === 1) { $ops[] = $t; continue; }
    $pc = substr($t, -1) === '%'; $num = $pc ? substr($t, 0, -1) : $t;
    if (!is_numeric($num)) return null;
    $vals[] = (float) $num / ($pc ? 100 : 1); $pcf[] = $pc;
  }
  if (count($vals) !== count($ops) + 1) return null;
  $v2 = [$vals[0]]; $f2 = [false]; $o2 = [];        // اول ضرب و تقسیم
  foreach ($ops as $i => $op) {
    $nx = $vals[$i + 1]; $last = count($v2) - 1;
    if ($op === '*') { $v2[$last] *= $nx; $f2[$last] = false; }
    elseif ($op === '/') { if ($nx == 0.0) return null; $v2[$last] /= $nx; $f2[$last] = false; }
    else { $o2[] = $op; $v2[] = $nx; $f2[] = $pcf[$i + 1]; }
  }
  $r = $v2[0];                                      // «200 + 10%» یعنی 200 به‌علاوه‌ی ۱۰ درصدِ 200
  foreach ($o2 as $i => $op) { $x = $f2[$i + 1] ? $r * $v2[$i + 1] : $v2[$i + 1]; $r = $op === '+' ? $r + $x : $r - $x; }
  return (is_nan($r) || is_infinite($r) || abs($r) > 1e15) ? null : $r;
}
function calcRaw(float $v): string { $s = rtrim(rtrim(sprintf('%.8F', $v), '0'), '.'); return ($s === '' || $s === '-0') ? '0' : $s; }
function calcFmt(float $v): string { $s = rtrim(rtrim(number_format($v, 8, '.', ','), '0'), '.'); return ($s === '' || $s === '-0') ? '0' : $s; }

/* ---------- ماشین‌حساب شیشه‌ای ---------- */
function calcFile(int $chat, int $mid): string { return DATA_DIR . "/calc_{$chat}_{$mid}.json"; }
function calcGc(): void {
  if (mt_rand(1, 20) !== 1) return;
  foreach (glob(DATA_DIR . '/calc_*.json') ?: [] as $f) if (time() - (int) @filemtime($f) > 259200) @unlink($f);
}
function calcKb(): string {
  $b = function (string $t, string $d, string $style = ''): array {
    $x = ['text'=>$t, 'callback_data'=>'c:' . $d]; if ($style !== '') $x['style'] = $style; return $x;
  };
  return json_encode(['inline_keyboard' => [
    [$b('AC', 'ac', 'danger'), $b('⌫', 'bs'), $b('%', 'pc', 'primary'), $b('÷', '/', 'primary')],
    [$b('7', '7'), $b('8', '8'), $b('9', '9'), $b('×', '*', 'primary')],
    [$b('4', '4'), $b('5', '5'), $b('6', '6'), $b('−', '-', 'primary')],
    [$b('1', '1'), $b('2', '2'), $b('3', '3'), $b('+', '+', 'primary')],
    [$b('0', '0'), $b('.', 'dot'), $b('✖️ بستن', 'x', 'danger'), $b('=', 'eq', 'success')],
  ]], JSON_UNESCAPED_UNICODE);
}
function calcShow(string $e): string {
  if ($e === '') return '0';
  return trim(preg_replace('/(?<=[0-9.%])([+\-*\/])/', ' $1 ', strtr($e, ['*'=>'*', '/'=>'/'])) ?? $e);
}
function calcText(array $st): string {
  $o = "🧮 <b>ماشین‌حساب</b>\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n";
  $e = (string)($st['e'] ?? ''); $h = (string)($st['h'] ?? '');
  if ($h !== '') return $o . '<code>' . htmlspecialchars(strtr(calcShow($h), ['*'=>'×', '/'=>'÷'])) . "</code>\n= <b>" . calcFmt((float) $e) . '</b>';
  $o .= '<code>' . htmlspecialchars(strtr(calcShow($e), ['*'=>'×', '/'=>'÷'])) . '</code>';
  if (preg_match('/[0-9.%][+\-*\/]|%/', $e)) { $v = calcEval($e); if ($v !== null) $o .= "\n= <b>" . calcFmt($v) . '</b>'; }
  return $o;
}
function calcOpen(int $chat, int $uid, int $replyTo = 0): void {
  $st = ['e'=>'', 'h'=>'', 'f'=>false, 'o'=>$uid];
  $p = ['chat_id'=>$chat, 'text'=>calcText($st), 'parse_mode'=>'HTML', 'reply_markup'=>calcKb()];
  if ($replyTo > 0) $p['reply_to_message_id'] = $replyTo;
  $r = tg('sendMessage', $p); $mid = (int) ($r['result']['message_id'] ?? 0);
  if ($mid) { file_put_contents(calcFile($chat, $mid), json_encode($st)); calcGc(); }
}
function calcTrigger(string $text): bool {
  $t = ltrim(norm($text), '/'); $t = preg_replace('/@.*$/', '', $t);
  return in_array($t, ['calc', 'calculator', 'ماشین حساب', 'ماشینحساب', 'محاسبه گر', 'محاسبه‌گر'], true);
}
function handleCalcCb(array $cq, string $data): void {
  $act = substr($data, 2); $msg = $cq['message'] ?? null; $uid = (int) ($cq['from']['id'] ?? 0); $qid = $cq['id'];
  if (!$msg) { tg('answerCallbackQuery', ['callback_query_id'=>$qid]); return; }
  $chat = (int) $msg['chat']['id']; $mid = (int) $msg['message_id'];
  if ($act === 'open') { calcOpen($chat, $uid, $mid); tg('answerCallbackQuery', ['callback_query_id'=>$qid]); return; }
  $f = calcFile($chat, $mid);
  $st = is_file($f) ? json_decode((string) file_get_contents($f), true) : null;
  if (!is_array($st)) { tg('answerCallbackQuery', ['callback_query_id'=>$qid, 'text'=>'این ماشین‌حساب منقضی شده؛ دوباره /calc بزنید', 'show_alert'=>'true']); return; }
  if ((int)$st['o'] !== $uid) { tg('answerCallbackQuery', ['callback_query_id'=>$qid, 'text'=>'این ماشین‌حساب برای شخص دیگری است؛ برای خودتان /calc بزنید']); return; }
  if ($act === 'x') { tg('deleteMessage', ['chat_id'=>$chat, 'message_id'=>$mid]); @unlink($f); tg('answerCallbackQuery', ['callback_query_id'=>$qid]); return; }
  $e = (string)$st['e']; $fresh = !empty($st['f']); $h = ''; $err = '';
  if (strlen($act) === 1 && ctype_digit($act)) {
    if ($fresh) { $e = ''; $fresh = false; }
    if (substr($e, -1) !== '%' && strlen($e) < 60) { if ($e === '0') $e = ''; elseif (preg_match('/(^|[+\-*\/])0$/', $e)) $e = substr($e, 0, -1); $e .= $act; }
  } elseif ($act === 'dot') {
    if ($fresh) { $e = ''; $fresh = false; }
    $parts = preg_split('/[+\-*\/]/', $e) ?: ['']; $last = (string) end($parts);
    if (substr($e, -1) !== '%' && strpos($last, '.') === false && strlen($e) < 60) $e .= ($last === '' ? '0.' : '.');
  } elseif (in_array($act, ['+', '-', '*', '/'], true)) {
    $fresh = false;
    if ($e === '') { if ($act === '-') $e = '-'; }
    elseif ($e === '-') { /* فقط منفی؛ عملگر دیگر نمی‌پذیرد */ }
    elseif (preg_match('/[+\-*\/]$/', $e)) $e = substr($e, 0, -1) . $act;
    elseif (strlen($e) < 60) $e .= $act;
  } elseif ($act === 'pc') {
    $fresh = false; if (preg_match('/[0-9.]$/', $e)) $e .= '%';
  } elseif ($act === 'bs') {
    $fresh = false; $e = (string) substr($e, 0, -1);
  } elseif ($act === 'ac') {
    $e = ''; $fresh = false;
  } elseif ($act === 'eq') {
    $v = calcEval($e);
    if ($v === null) $err = '⚠️ عبارت نامعتبر است';
    elseif (preg_match('/[+\-*\/%]/', ltrim($e, '-'))) { $h = $e; $e = calcRaw($v); $fresh = true; }
  }
  $st['e'] = $e; $st['f'] = $fresh; $st['h'] = $h;
  file_put_contents($f, json_encode($st));
  $text = calcText($st) . ($err !== '' ? "\n" . $err : '');
  tg('editMessageText', ['chat_id'=>$chat, 'message_id'=>$mid, 'text'=>$text, 'parse_mode'=>'HTML', 'reply_markup'=>calcKb()]);
  tg('answerCallbackQuery', ['callback_query_id'=>$qid]);
}

/* ---------- «3 دلار» یا «دلار 3» → محاسبه مقدار ---------- */
function parseAmount(string $text): ?array {
  $t = norm($text);
  $t = strtr($t, ['٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9','٫'=>'.','٬'=>',']);
  $t = trim($t); if ($t === '' || mb_strlen($t) > 40) return null;
  $mult = ['هزار'=>1e3, 'میلیون'=>1e6, 'میلیارد'=>1e9];
  $mu = '';
  if (preg_match('/^(\.[0-9]+|[0-9][0-9,]*(?:\.[0-9]+)?)\s*(هزار|میلیون|میلیارد)?\s*(.+)$/u', $t, $m)) { $num = $m[1]; $mu = $m[2]; $name = $m[3]; }
  elseif (preg_match('/^(.+?)\s+(\.[0-9]+|[0-9][0-9,]*(?:\.[0-9]+)?)$/u', $t, $m)) { $name = $m[1]; $num = $m[2]; }
  else return null;
  $amount = (float) str_replace(',', '', $num) * ($mu !== '' ? $mult[$mu] : 1.0);
  if ($amount <= 0 || $amount > 1e15) return null;
  $name = trim((string) preg_replace('/\s+(چقدر میشه|چقدر می شه|چقدره|چقد میشه|چنده|چند میشه|چند تومنه|چند تومان|به تومان|چنده قیمتش)$/u', '', $name));
  $name = trim((string) preg_replace('/^(قیمت|نرخ)\s+/u', '', $name));
  if ($name === '') return null;
  $k = findItem($name) ?: worldItemKey($name, false);
  if ($k) return [$amount, 'item', $k];
  $wc = worldLookup($name, false);
  return $wc ? [$amount, 'world', $wc] : null;
}
function fmtAmt(float $a): string { $s = rtrim(rtrim(number_format($a, 6, '.', ','), '0'), '.'); return $s === '' ? '0' : $s; }
function amountText(array $am): string {
  global $ITEMS; [$amount, $kind, $key] = $am; $ut = usdToman();
  if ($kind === 'item') {
    $it = $ITEMS[$key]; $p = getPrice($it, $key); if (!$p) return tt('unavailable', ['t'=>$it['t']]);
    $tm = isset($p['toman']) ? (float)$p['toman'] : (float)$p['usd'] * $ut;
    $us = isset($p['usd']) ? (float)$p['usd'] : ($ut > 0 ? $tm / $ut : 0.0);
    $icon = (string)$it['e']; $name = (string)$it['t'];
  } else {
    $w = worldData()[$key]; $p = worldPrice($key); if (!$p) return '⚠️ فعلا نرخ ' . $w['n'] . ' در دسترس نیست.';
    $tm = (float)$p['toman']; $us = (float)$p['usd']; $icon = flagEmoji($w['iso']); $name = (string)$w['n'];
  }
  $d = function (float $v): string { return n($v, $v < 1 ? 4 : 2); };
  $o = $icon . ' <b>' . fmtAmt($amount) . ' ' . $name . "</b>\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n<blockquote>💰 <b>" . tomanFmt($tm * $amount) . '</b> تومان';
  if ($us > 0) $o .= "\n💲 <b>$" . $d($us * $amount) . '</b>';
  $o .= "</blockquote>\n<blockquote>🔹 <b>۱ " . $name . "</b>\n💰 " . tomanFmt($tm) . ' تومان';
  if ($us > 0) $o .= "\n💲 $" . $d($us);
  return $o . "</blockquote>\n🕒 " . jdate() . "\n\n🤖 " . tt('brand');
}
