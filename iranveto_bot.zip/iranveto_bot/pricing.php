<?php
/**
 * قیمت‌گذاری هوشمند محصولات (وابسته به نرخ ارز)
 *
 * فرمول (همیشه از «قیمت پایه» و «نرخ مبنا» حساب می‌شود، نه از قیمت قبلی؛ پس خطای تجمعی ندارد):
 *   ضریب هر ارز  k = اثر٪ / گام٪          (مثلاً ۱۰٪ اثر به‌ازای ۱۰٪ گام => k = 1)
 *   تغییر هر ارز  = نرخ_فعلی / نرخ_مبنا - 1
 *   قیمت = قیمت_پایه × (1 + Σ k × تغییر)  ← سپس حداقل/حداکثر و گردکردن
 *
 * ذخیره‌سازی: data/products.json (با قفل فایل، مثل بقیه‌ی تنظیمات ربات)
 */
declare(strict_types=1);

const PR_FILE    = DATA_DIR . '/products.json';
const PR_LOG_MAX = 30;

/* ---------- داده ---------- */
/** ارزهای قابل انتخاب (کلید آیتم‌های ربات => برچسب) */
function prCurrencies(): array {
  return ['usd'=>'🇺🇸 دلار', 'eur'=>'🇪🇺 یورو', 'gbp'=>'🇬🇧 پوند', 'aed'=>'🇦🇪 درهم', 'try'=>'🇹🇷 لیر',
          'usdt'=>'💵 تتر', 'gold18'=>'🥇 طلای ۱۸', 'coin'=>'🪙 سکه امامی', 'btc'=>'₿ بیت‌کوین', 'eth'=>'⟠ اتریوم'];
}
function prDb(): array {
  $d = is_file(PR_FILE) ? json_decode((string)file_get_contents(PR_FILE), true) : null;
  return (is_array($d) && isset($d['items'])) ? $d : ['seq'=>0, 'items'=>[]];
}
/** خواندن/نوشتن امن زیر قفل؛ $fn بانک را با رفرنس می‌گیرد */
function prMutate(callable $fn) {
  $fh = @fopen(PR_FILE, 'c+'); if (!$fh) return null;
  flock($fh, LOCK_EX);
  $db = json_decode((string) stream_get_contents($fh), true);
  if (!is_array($db) || !isset($db['items'])) $db = ['seq'=>0, 'items'=>[]];
  $res = $fn($db);
  ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($db, JSON_UNESCAPED_UNICODE)); fflush($fh);
  flock($fh, LOCK_UN); fclose($fh);
  return $res;
}
function prGet(string $id): ?array { return prDb()['items'][$id] ?? null; }

function prNum(string $s): ?float {
  $s = strtr(trim($s), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
                        '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
                        '٫'=>'.', '٬'=>'', ','=>'', '،'=>'', ' '=>'', '٪'=>'', '%'=>'']);
  return ($s !== '' && is_numeric($s)) ? (float)$s : null;
}
function prJdate(int $ts): string {
  [$gy,$gm,$gd] = array_map('intval', explode('-', date('Y-n-j', $ts)));
  $gdm = [0,31,59,90,120,151,181,212,243,273,304,334];
  $gy2 = $gm > 2 ? $gy + 1 : $gy;
  $days = 355666 + 365*$gy + intdiv($gy2+3,4) - intdiv($gy2+99,100) + intdiv($gy2+399,400) + $gd + $gdm[$gm-1];
  $jy = -1595 + 33*intdiv($days,12053); $days %= 12053;
  $jy += 4*intdiv($days,1461); $days %= 1461;
  if ($days > 365) { $jy += intdiv($days-1,365); $days = ($days-1) % 365; }
  if ($days < 186) { $jm = 1 + intdiv($days,31); $jd = 1 + $days % 31; }
  else { $jm = 7 + intdiv($days-186,30); $jd = 1 + ($days-186) % 30; }
  return sprintf('%04d/%02d/%02d %s', $jy, $jm, $jd, date('H:i', $ts));
}
function prPct(float $old, float $new): float { return $old > 0 ? ($new / $old - 1) * 100 : 0.0; }
function prFmtPct(float $p): string { return ($p >= 0 ? '+' : '') . number_format($p, 2) . '%'; }
function prT(float $v): string { return number_format($v, 0) . ' تومان'; }
function prH(string $s): string { return htmlspecialchars($s); }

/* ---------- نرخ ارز و محاسبه ---------- */
/** نرخ لحظه‌ای (تومان) برای کلیدهای ارز؛ اگر نرخی نیامد null */
function prRates(array $keys): array {
  global $ITEMS; $out = [];
  foreach (array_unique($keys) as $k) {
    $v = null;
    if (isset($ITEMS[$k])) { $p = getPrice($ITEMS[$k]); if ($p && isset($p['toman']) && (float)$p['toman'] > 0) $v = (float)$p['toman']; }
    $out[$k] = $v;
  }
  return $out;
}
/** قیمت محاسبه‌شده؛ اگر نرخ یکی از ارزها در دسترس نباشد null (قیمت دست نمی‌خورد) */
function prCompute(array $p, array $rates): ?float {
  $base = (float)$p['base']; if ($base <= 0) return null;
  $sum = 0.0;
  foreach ($p['deps'] as $d) {
    $r = $rates[$d['k']] ?? null; $br = (float)$d['br']; $step = (float)$d['step'];
    if (!$r || $r <= 0 || $br <= 0) return null;
    if ($step <= 0) continue;
    $sum += ((float)$d['eff'] / $step) * ($r / $br - 1);
  }
  $price = max(0.0, $base * (1 + $sum));
  $mn = (float)($p['min'] ?? 0); $mx = (float)($p['max'] ?? 0);
  if ($mn > 0) $price = max($price, $mn);
  if ($mx > 0) $price = min($price, $mx);
  $rd = (int)($p['rnd'] ?? 0);
  if ($rd > 0) $price = round($price / $rd) * $rd;
  return $price;
}
function prLog(array &$p, float $old, float $new, array $rates, string $why): void {
  $p['log'][] = ['t'=>time(), 'old'=>$old, 'new'=>$new, 'pct'=>round(prPct($old, $new), 4), 'rates'=>$rates, 'why'=>$why];
  if (count($p['log']) > PR_LOG_MAX) $p['log'] = array_slice($p['log'], -PR_LOG_MAX);
  $p['upd'] = time();
}
/** محاسبه‌ی دوباره‌ی یک محصول خودکار. true = قیمت عوض شد. (باید داخل prMutate صدا زده شود) */
function prRefresh(array &$p, string $why = 'auto'): bool {
  if (empty($p['on']) || ($p['mode'] ?? '') !== 'auto' || empty($p['deps'])) return false;
  $rates = prRates(array_column($p['deps'], 'k'));
  $new = prCompute($p, $rates); if ($new === null) return false;
  $old = (float)$p['price'];
  if (abs($new - $old) < 0.5) return false;            // بدون تغییر واقعی = بدون ثبت تکراری
  $p['price'] = $new; prLog($p, $old, $new, $rates, $why);
  return true;
}
function prUpdateAll(): int {
  return (int) prMutate(function (array &$db) {
    $n = 0;
    foreach ($db['items'] as &$p) if (prRefresh($p)) $n++;
    unset($p);
    return $n;
  });
}
/** نرخ‌های فعلی را به‌عنوان نرخ مبنا ثبت می‌کند */
function prRebaseRates(array &$p): void {
  $rates = prRates(array_column($p['deps'], 'k'));
  foreach ($p['deps'] as &$d) if (!empty($rates[$d['k']])) $d['br'] = $rates[$d['k']];
  unset($d);
}

/* ---------- نمایش به کاربران ---------- */
function prUserText(string $text): ?string {
  $t = norm(ltrim($text, '/')); $t = preg_replace('/^(قیمت|نرخ)\s+/u', '', $t);
  if ($t === '' || mb_strlen($t) > 40) return null;
  $hit = null;
  foreach (prDb()['items'] as $id => $p) if (!empty($p['on']) && norm((string)$p['name']) === $t) { $hit = (string)$id; break; }
  if ($hit === null) return null;
  $p = prMutate(function (array &$db) use ($hit) { if (!isset($db['items'][$hit])) return null; prRefresh($db['items'][$hit]); return $db['items'][$hit]; });
  if (!$p) return null;
  $o = '🏷 <b>' . prH((string)$p['name']) . "</b>\n\n💰 <b>" . number_format((float)$p['price'], 0) . "</b> تومان";
  $last = end($p['log']);
  if ($last && abs((float)$last['pct']) > 0) $o .= "\n" . ((float)$last['pct'] >= 0 ? '📈 ' : '📉 ') . prFmtPct((float)$last['pct']);
  return $o . "\n\n🕒 " . jdate() . "\n\n🤖 " . tt('brand');
}

/* ---------- صفحه‌های پنل ---------- */
function prBack(string $to = 'p:pr'): array { return [pb('↩️ بازگشت', $to)]; }
function prCancel(string $id = ''): array { return [[pb('↩️ انصراف', $id !== '' ? "p:pr_v:$id" : 'p:pr')]]; }

function prHome(int $page = 0): array {
  $db = prDb(); $items = $db['items']; $per = 8; $total = count($items);
  $pages = max(1, (int) ceil($total / $per)); $page = max(0, min($page, $pages - 1));
  $act = 0; foreach ($items as $p) if (!empty($p['on'])) $act++;
  $t = "🏷 <b>قیمت‌گذاری هوشمند</b>\n\nمحصولات: <b>$total</b> · فعال: <b>$act</b>\n"
     . "قیمت محصولات خودکار با تغییر نرخ ارز به‌روز می‌شود.\n(به‌روزرسانی دوره‌ای نیاز به کرون دارد؛ پایین همین پیام را ببینید)\n\n"
     . ($total ? 'یک محصول را انتخاب کنید:' : 'هنوز محصولی ثبت نشده است.');
  $rows = [[pb('➕ محصول جدید', 'p:pr_new', 'success'), pb('🔄 بروزرسانی همه', 'p:pr_ua')]];
  foreach (array_slice($items, $page * $per, $per, true) as $id => $p) {
    $rows[] = [pb((!empty($p['on']) ? '' : '⏸ ') . (($p['mode'] ?? '') === 'auto' ? '🤖 ' : '✋ ') . mb_substr((string)$p['name'], 0, 20) . ' — ' . number_format((float)$p['price'], 0), "p:pr_v:$id")];
  }
  if ($pages > 1) {
    $nav = [];
    if ($page > 0) $nav[] = pb('◀️', 'p:pr_l:' . ($page - 1));
    $nav[] = pb(($page + 1) . '/' . $pages, 'p:pr_l:' . $page);
    if ($page < $pages - 1) $nav[] = pb('▶️', 'p:pr_l:' . ($page + 1));
    $rows[] = $nav;
  }
  if ($total) $rows[] = [pb('📊 گزارش تغییرات', 'p:pr_rep')];
  $rows[] = [pb('↩️ بازگشت به پنل', 'p:home')];
  return [$t, $rows];
}
function prView(string $id, string $note = ''): array {
  $p = prGet($id); if (!$p) return prHome();
  $cur = prCurrencies(); $rates = prRates(array_column($p['deps'], 'k'));
  $auto = ($p['mode'] ?? '') === 'auto'; $mn = (float)($p['min'] ?? 0); $mx = (float)($p['max'] ?? 0); $rd = (int)($p['rnd'] ?? 0);
  $t = ($note !== '' ? "$note\n\n" : '') . '🏷 <b>' . prH((string)$p['name']) . "</b>\n\n"
     . 'وضعیت: ' . (!empty($p['on']) ? '✅ فعال' : '⏸ غیرفعال') . ' · حالت: ' . ($auto ? '🤖 خودکار' : '✋ دستی') . "\n"
     . '💰 قیمت پایه: <b>' . prT((float)$p['base']) . "</b>\n"
     . '💳 قیمت فعلی: <b>' . prT((float)$p['price']) . '</b> (' . prFmtPct(prPct((float)$p['base'], (float)$p['price'])) . " نسبت به پایه)\n"
     . '⬇️ حداقل: ' . ($mn > 0 ? prT($mn) : '—') . ' · ⬆️ حداکثر: ' . ($mx > 0 ? prT($mx) : '—') . "\n"
     . '🔘 گردکردن: ' . ($rd > 0 ? 'به ' . number_format($rd) : 'ندارد') . "\n\n🔗 <b>وابستگی ارزی</b>\n";
  if (!$p['deps']) $t .= "— ندارد —\n";
  foreach ($p['deps'] as $d) {
    $r = $rates[$d['k']] ?? null; $br = (float)$d['br'];
    $t .= '• ' . ($cur[$d['k']] ?? $d['k']) . ': هر ' . rtrim(rtrim(number_format((float)$d['step'], 2), '0'), '.') . '٪ تغییر ← '
        . rtrim(rtrim(number_format((float)$d['eff'], 2), '0'), '.') . "٪ اثر\n   مبنا: " . number_format($br) . ' · الان: ' . ($r ? number_format($r) . ' (' . prFmtPct(prPct($br, $r)) . ')' : 'نامشخص') . "\n";
  }
  if ($auto && !$p['deps']) $t .= "⚠️ حالت خودکار بدون ارز تغییری ایجاد نمی‌کند.\n";
  $t .= "\n🕒 آخرین بروزرسانی: " . (!empty($p['upd']) ? prJdate((int)$p['upd']) : '—');
  return [$t, [
    [pb('✏️ نام', "p:pr_en:$id"), pb('💰 قیمت پایه', "p:pr_eb:$id")],
    [pb('🔗 ارزها', "p:pr_c:$id"), pb('⬇️⬆️ حداقل/حداکثر', "p:pr_mm:$id")],
    [pb($auto ? '✋ تبدیل به دستی' : '🤖 تبدیل به خودکار', "p:pr_md:$id"), pb('✍️ قیمت دستی', "p:pr_mp:$id")],
    [pb('🔘 گردکردن', "p:pr_rdm:$id"), pb('🔁 ریست مبنا', "p:pr_rb:$id")],
    [pb(!empty($p['on']) ? '⏸ غیرفعال کردن' : '✅ فعال کردن', "p:pr_on:$id", !empty($p['on']) ? '' : 'success'), pb('📜 گزارش', "p:pr_log:$id")],
    [pb('🗑 حذف', "p:pr_del:$id", 'danger')],
    prBack(),
  ]];
}
function prCurScreen(string $id): array {
  $p = prGet($id); if (!$p) return prHome();
  $have = array_column($p['deps'], 'k'); $rows = [];
  foreach (array_chunk(array_keys(prCurrencies()), 2) as $pair) {
    $r = []; foreach ($pair as $k) $r[] = pb((in_array($k, $have, true) ? '✅ ' : '') . prCurrencies()[$k], "p:pr_ck:$id:$k");
    $rows[] = $r;
  }
  $rows[] = prBack("p:pr_v:$id");
  return ["🔗 <b>ارزهای وابسته به «" . prH((string)$p['name']) . "»</b>\n\nروی هر ارز بزنید تا اضافه، ویرایش یا حذف شود. می‌توانید چند ارز هم‌زمان انتخاب کنید (اثرها جمع می‌شوند).", $rows];
}
function prDepScreen(string $id, string $k): array {
  $p = prGet($id); $cur = prCurrencies(); if (!$p || !isset($cur[$k])) return prHome();
  $dep = null; foreach ($p['deps'] as $d) if ($d['k'] === $k) $dep = $d;
  $t = '🔗 <b>' . $cur[$k] . '</b> ← ' . prH((string)$p['name']) . "\n\n"
     . ($dep ? 'تنظیم فعلی: هر ' . $dep['step'] . '٪ تغییر ارز ← ' . $dep['eff'] . "٪ تغییر قیمت\n" : "هنوز وابسته نیست.\n")
     . "\nیکی از حالت‌های آماده را بزنید یا «تنظیم دستی» را انتخاب کنید.\nمثال: «۱۰ ← ۱۰» یعنی با هر ۱۰٪ افزایش ارز، قیمت ۱۰٪ بالا می‌رود و با کاهش، به همان نسبت پایین می‌آید.";
  $rows = [
    [pb('۱۰٪ ← ۱۰٪ (هم‌نسبت)', "p:pr_ds:$id:$k:10:10")],
    [pb('۱۰٪ ← ۵٪', "p:pr_ds:$id:$k:10:5"), pb('۱۰٪ ← ۲۰٪', "p:pr_ds:$id:$k:10:20")],
    [pb('✏️ تنظیم دستی', "p:pr_dm:$id:$k")],
  ];
  if ($dep) $rows[] = [pb('🗑 حذف این ارز', "p:pr_dx:$id:$k", 'danger')];
  $rows[] = prBack("p:pr_c:$id");
  return [$t, $rows];
}
function prLogScreen(string $id): array {
  $p = prGet($id); if (!$p) return prHome(); $cur = prCurrencies();
  $t = '📜 <b>گزارش تغییرات «' . prH((string)$p['name']) . "»</b>\n\n";
  $log = array_reverse(array_slice($p['log'], -8));
  if (!$log) $t .= '— هنوز تغییری ثبت نشده —';
  foreach ($log as $e) {
    $t .= '🕒 ' . prJdate((int)$e['t']) . "\n   " . number_format((float)$e['old']) . ' ← <b>' . number_format((float)$e['new']) . '</b> (' . prFmtPct((float)$e['pct']) . ')';
    $rs = []; foreach ((array)($e['rates'] ?? []) as $k => $v) if ($v) $rs[] = ($cur[$k] ?? $k) . ' ' . number_format((float)$v);
    $why = ['auto'=>'خودکار', 'manual'=>'دستی', 'rebase'=>'ریست مبنا', 'base'=>'تغییر پایه', 'mode'=>'تغییر حالت', 'limit'=>'تغییر محدوده'][$e['why']] ?? (string)$e['why'];
    $t .= ($rs ? "\n   نرخ ارز در محاسبه: " . implode(' ، ', $rs) : '') . "\n   (" . $why . ")\n\n";
  }
  return [rtrim($t), [prBack("p:pr_v:$id")]];
}
function prReport(): array {
  $items = prDb()['items']; $t = "📊 <b>گزارش تغییرات قیمت‌ها</b>\n\n";
  foreach ($items as $p) {
    $t .= '🏷 <b>' . prH((string)$p['name']) . '</b> — ' . number_format((float)$p['price']) . " تومان\n";
    $e = end($p['log']);
    $t .= $e ? '   قبلی: ' . number_format((float)$e['old']) . ' · تغییر: ' . prFmtPct((float)$e['pct']) . ' · ' . prJdate((int)$e['t']) . "\n" : "   بدون تغییر ثبت‌شده\n";
  }
  return [mb_substr(rtrim($t), 0, 3900), [prBack()]];
}

function prRoute(array $a, int $uid): array {
  $s = $a[0]; $id = (string)($a[1] ?? ''); $cur = prCurrencies();
  switch ($s) {
    case 'pr': stClear($uid); return prHome();
    case 'pr_l': return prHome((int)$id);
    case 'pr_v': return prView($id);
    case 'pr_ua': $n = prUpdateAll(); [$t, $r] = prHome(); return ["✅ بروزرسانی انجام شد؛ قیمت <b>$n</b> محصول تغییر کرد.\n\n" . $t, $r];
    case 'pr_rep': return prReport();
    case 'pr_log': return prLogScreen($id);
    case 'pr_new': stSet($uid, ['a'=>'pr_name']); return ["🏷 نام محصول را بفرستید (مثلاً <code>بستنی</code>):", prCancel()];
    case 'pr_en': stSet($uid, ['a'=>'pr_ren', 'id'=>$id]); return ['✏️ نام جدید را بفرستید:', prCancel($id)];
    case 'pr_eb': stSet($uid, ['a'=>'pr_base', 'id'=>$id]); return ["💰 قیمت پایه‌ی جدید را به تومان بفرستید.\n(نرخ‌های مبنای ارزها هم با نرخ همین لحظه دوباره تنظیم می‌شوند)", prCancel($id)];
    case 'pr_mp': stSet($uid, ['a'=>'pr_man', 'id'=>$id]); return ["✍️ قیمت دستی را به تومان بفرستید.\nمحصول به حالت «دستی» می‌رود.", prCancel($id)];
    case 'pr_mm': stSet($uid, ['a'=>'pr_mm', 'id'=>$id]); return ["⬇️⬆️ حداقل و حداکثر را این‌طور بفرستید:\n<code>حداقل | حداکثر</code>\nمثال: <code>40000 | 80000</code>\nبرای نداشتن محدودیت <code>0</code> بگذارید.", prCancel($id)];
    case 'pr_dm': stSet($uid, ['a'=>'pr_dep', 'id'=>$id, 'k'=>(string)($a[2] ?? '')]);
      return ["✏️ این‌طور بفرستید:\n<code>گام٪ | اثر٪</code>\nمثال: <code>10 | 10</code>\n(اثر منفی هم مجاز است؛ یعنی قیمت برعکس ارز حرکت کند)", prCancel($id)];
    case 'pr_c': return prCurScreen($id);
    case 'pr_ck': return prDepScreen($id, (string)($a[2] ?? ''));
    case 'pr_ds':
      $k = (string)($a[2] ?? ''); $step = (float)($a[3] ?? 0); $eff = (float)($a[4] ?? 0);
      if (!isset($cur[$k]) || $step <= 0) return prView($id);
      prMutate(function (array &$db) use ($id, $k, $step, $eff) { if (isset($db['items'][$id])) prSetDep($db['items'][$id], $k, $step, $eff); });
      return prView($id, '✅ وابستگی ذخیره شد.');
    case 'pr_dx':
      $k = (string)($a[2] ?? '');
      prMutate(function (array &$db) use ($id, $k) { if (!isset($db['items'][$id])) return;
        $db['items'][$id]['deps'] = array_values(array_filter($db['items'][$id]['deps'], fn($d) => $d['k'] !== $k)); });
      return prView($id, '🗑 ارز حذف شد.');
    case 'pr_md':
      $note = '';
      prMutate(function (array &$db) use ($id, &$note) {
        if (!isset($db['items'][$id])) return; $p = &$db['items'][$id];
        if (($p['mode'] ?? '') === 'auto') { $p['mode'] = 'manual'; $note = '✋ حالت دستی شد؛ قیمت ثابت می‌ماند.'; }
        else { $p['mode'] = 'auto'; prRefresh($p, 'mode'); $note = '🤖 حالت خودکار فعال شد و قیمت از روی پایه و نرخ ارز دوباره محاسبه شد.'; }
      });
      return prView($id, $note);
    case 'pr_on':
      prMutate(function (array &$db) use ($id) { if (isset($db['items'][$id])) { $p = &$db['items'][$id]; $p['on'] = empty($p['on']); if ($p['on']) prRefresh($p); } });
      return prView($id);
    case 'pr_rdm':
      $rows = []; foreach ([0=>'بدون گردکردن', 100=>'۱۰۰ تومان', 1000=>'۱,۰۰۰ تومان', 5000=>'۵,۰۰۰ تومان', 10000=>'۱۰,۰۰۰ تومان'] as $v => $l) $rows[] = [pb($l, "p:pr_rd:$id:$v")];
      $rows[] = prBack("p:pr_v:$id"); return ['🔘 قیمت به نزدیک‌ترین مضرب کدام عدد گرد شود؟', $rows];
    case 'pr_rd':
      $v = max(0, (int)($a[2] ?? 0));
      prMutate(function (array &$db) use ($id, $v) { if (isset($db['items'][$id])) { $db['items'][$id]['rnd'] = $v; prRefresh($db['items'][$id], 'limit'); } });
      return prView($id, '✅ ذخیره شد.');
    case 'pr_rb':
      prMutate(function (array &$db) use ($id) { if (!isset($db['items'][$id])) return; $p = &$db['items'][$id];
        $p['base'] = (float)$p['price']; prRebaseRates($p); });
      return prView($id, '🔁 قیمت فعلی به‌عنوان پایه و نرخ‌های فعلی به‌عنوان مبنا ثبت شد.');
    case 'pr_del': if (!prGet($id)) return prHome();
      return ['⚠️ «' . prH((string)prGet($id)['name']) . '» حذف شود؟ این کار برگشت ندارد.', [[pb('🗑 بله، حذف شود', "p:pr_delx:$id", 'danger')], prBack("p:pr_v:$id")]];
    case 'pr_delx':
      prMutate(function (array &$db) use ($id) { unset($db['items'][$id]); });
      return prHome();
  }
  return prHome();
}
function prSetDep(array &$p, string $k, float $step, float $eff): void {
  $rate = prRates([$k])[$k] ?? null;
  foreach ($p['deps'] as &$d) if ($d['k'] === $k) {            // ویرایش: مبنای قبلی حفظ می‌شود
    $d['step'] = $step; $d['eff'] = $eff; unset($d); prAfterDep($p); return;
  }
  unset($d);
  if (!$rate) { $p['deps'][] = ['k'=>$k, 'step'=>$step, 'eff'=>$eff, 'br'=>0.0]; }       // نرخ در دسترس نیست؛ در اولین نرخ معتبر مبنا می‌شود
  else $p['deps'][] = ['k'=>$k, 'step'=>$step, 'eff'=>$eff, 'br'=>$rate];
  if (($p['mode'] ?? '') !== 'auto' && count($p['deps']) === 1) $p['mode'] = 'auto';
  prAfterDep($p);
}
function prAfterDep(array &$p): void {
  foreach ($p['deps'] as &$d) if ((float)$d['br'] <= 0) { $r = prRates([$d['k']])[$d['k']] ?? null; if ($r) $d['br'] = $r; }
  unset($d); prRefresh($p, 'auto');
}

/* ---------- ورودی‌های متنی ---------- */
function prInput(array $m, array $st, int $uid): bool {
  $chat = $m['chat']['id']; $text = trim((string)($m['text'] ?? '')); $a = (string)$st['a']; $id = (string)($st['id'] ?? '');
  $say = function (string $t, array $rows) use ($chat) { tg('sendMessage', ['chat_id'=>$chat, 'text'=>$t, 'parse_mode'=>'HTML', 'reply_markup'=>pkb($rows)]); };
  $open = fn(string $pid) => [[pb('🏷 باز کردن محصول', "p:pr_v:$pid")]];
  $bad  = function (string $msg) use ($say) { $say($msg . "\nدوباره بفرستید یا /cancel", [[pb('↩️ انصراف', 'p:pr')]]); };
  switch ($a) {
    case 'pr_name': case 'pr_ren':
      if ($text === '' || mb_strlen($text) > 40) { $bad('⚠️ نام باید ۱ تا ۴۰ کاراکتر باشد.'); return true; }
      if ($a === 'pr_ren') {
        prMutate(function (array &$db) use ($id, $text) { if (isset($db['items'][$id])) $db['items'][$id]['name'] = $text; });
        stClear($uid); $say('✅ نام ذخیره شد.', $open($id)); return true;
      }
      stSet($uid, ['a'=>'pr_newprice', 'name'=>$text]);
      $say('💰 قیمت اولیه‌ی «' . prH($text) . '» را به تومان بفرستید (مثلاً <code>50000</code>):', prCancel()); return true;
    case 'pr_newprice':
      $v = prNum($text); if ($v === null || $v <= 0) { $bad('⚠️ یک عدد معتبر بفرستید.'); return true; }
      $name = (string)($st['name'] ?? '');
      $nid = prMutate(function (array &$db) use ($name, $v) {
        $db['seq'] = (int)$db['seq'] + 1; $nid = (string)$db['seq'];
        $db['items'][$nid] = ['name'=>$name, 'base'=>$v, 'price'=>$v, 'mode'=>'manual', 'on'=>true, 'min'=>0, 'max'=>0, 'rnd'=>0, 'deps'=>[], 'upd'=>time(), 'log'=>[]];
        return $nid;
      });
      stClear($uid);
      $say('✅ محصول ثبت شد. حالا وابستگی ارزی را تنظیم کنید:', [[pb('🔗 تنظیم ارزها', "p:pr_c:$nid")], [pb('🏷 صفحه‌ی محصول', "p:pr_v:$nid")]]); return true;
    case 'pr_base':
      $v = prNum($text); if ($v === null || $v <= 0) { $bad('⚠️ یک عدد معتبر بفرستید.'); return true; }
      prMutate(function (array &$db) use ($id, $v) { if (!isset($db['items'][$id])) return; $p = &$db['items'][$id];
        $old = (float)$p['price']; $p['base'] = $v; prRebaseRates($p);
        $new = prCompute($p, prRates(array_column($p['deps'], 'k'))) ?? $v;
        if (($p['mode'] ?? '') !== 'auto') $new = $v;
        $p['price'] = $new; if (abs($new - $old) >= 0.5) prLog($p, $old, $new, [], 'base'); });
      stClear($uid); $say('✅ قیمت پایه ذخیره و مبنا از نو تنظیم شد.', $open($id)); return true;
    case 'pr_man':
      $v = prNum($text); if ($v === null || $v < 0) { $bad('⚠️ یک عدد معتبر بفرستید.'); return true; }
      prMutate(function (array &$db) use ($id, $v) { if (!isset($db['items'][$id])) return; $p = &$db['items'][$id];
        $old = (float)$p['price']; $p['mode'] = 'manual'; $p['price'] = $v; if (abs($v - $old) >= 0.5) prLog($p, $old, $v, [], 'manual'); });
      stClear($uid); $say('✅ قیمت دستی ثبت شد و محصول در حالت دستی است.', $open($id)); return true;
    case 'pr_mm':
      $pp = array_map('trim', explode('|', $text)); $mn = prNum($pp[0] ?? ''); $mx = prNum($pp[1] ?? '');
      if (count($pp) < 2 || $mn === null || $mx === null || $mn < 0 || $mx < 0 || ($mn > 0 && $mx > 0 && $mx < $mn)) { $bad('⚠️ فرمت: <code>حداقل | حداکثر</code> (حداکثر نباید کمتر از حداقل باشد)'); return true; }
      prMutate(function (array &$db) use ($id, $mn, $mx) { if (!isset($db['items'][$id])) return;
        $db['items'][$id]['min'] = $mn; $db['items'][$id]['max'] = $mx; prRefresh($db['items'][$id], 'limit'); });
      stClear($uid); $say('✅ محدوده ذخیره شد.', $open($id)); return true;
    case 'pr_dep':
      $k = (string)($st['k'] ?? ''); $pp = explode('|', $text); $step = prNum($pp[0] ?? ''); $eff = prNum($pp[1] ?? '');
      if (!isset(prCurrencies()[$k]) || count($pp) < 2 || $step === null || $eff === null || $step <= 0 || abs($eff) > 1000) { $bad('⚠️ فرمت: <code>گام٪ | اثر٪</code> مثل <code>10 | 10</code>'); return true; }
      prMutate(function (array &$db) use ($id, $k, $step, $eff) { if (isset($db['items'][$id])) prSetDep($db['items'][$id], $k, $step, $eff); });
      stClear($uid); $say('✅ وابستگی ذخیره شد.', [[pb('🔗 ارزها', "p:pr_c:$id")], [pb('🏷 صفحه‌ی محصول', "p:pr_v:$id")]]); return true;
  }
  stClear($uid); return false;
}
