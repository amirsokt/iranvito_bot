<?php
// این فایل فقط نمونه است. اگر config.php داری دست نزن؛ اگر نداری اسمش را بکن config.php و مقادیر را پر کن.
const BOT_TOKEN = 'PUT_YOUR_NEW_BOT_TOKEN';        // توکن جدید از BotFather
const BOT_USER  = 'IranVitochange_bot';            // بدون @
const SECRET    = 'یک-رشته-طولانی-و-تصادفی';         // هر مقداری، فقط حروف و عدد و خط‌تیره
const OWNER_ID  = 0;                               // آیدی عددی خودت (از /id در ربات)
const ADMIN_IDS = [
    // 123456789,   // آیدی عددی ادمین‌های دیگر
];
