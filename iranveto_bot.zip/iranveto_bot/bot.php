<?php
/**
 * IranVito Change | ایرانویتو چنج
 * ربات قیمت (ارز، طلا، سکه، نفت، کریپتو) + عکس کارت چارت مینیمال
 * نیازمندی: PHP 7.4+ با افزونه‌های curl و gd (با FreeType)
 */
declare(strict_types=1);
date_default_timezone_set('Asia/Tehran');
require __DIR__ . '/config.php';
if (!defined('CHART_STYLE')) define('CHART_STYLE', 'candle');   // 'candle' یا 'line' (در config.php هم می‌شود تغییر داد)

const BRAND      = 'IranVito Change | ایرانویتو چنج';
const CACHE_TTL  = 60;
const CACHE_DIR  = __DIR__ . '/cache';
const IRAN_API   = 'https://call5.tgju.org/ajax.json';   // غیررسمی
const CG         = 'https://api.coingecko.com/api/v3';
const FONT_B     = __DIR__ . '/fonts/Inter-Bold.otf';
const FONT_M     = __DIR__ . '/fonts/Inter-Medium.otf';
const FSCALE     = 0.75;  // پیکسل -> پوینت (GD با 96dpi کار می‌کند). اگر فونت‌ها بزرگ/کوچک بود فقط این عدد را عوض کن

if (!is_dir(CACHE_DIR)) { @mkdir(CACHE_DIR, 0755, true); @file_put_contents(CACHE_DIR . '/.htaccess', "Require all denied\nDeny from all\n"); }

require __DIR__ . '/panel.php';
require __DIR__ . '/pricing.php';
require __DIR__ . '/world.php';
require __DIR__ . '/calc.php';
require __DIR__ . '/menu.php';
function logx(string $m): void { @file_put_contents(CACHE_DIR . '/error.log', date('c') . ' ' . $m . "\n", FILE_APPEND); }
register_shutdown_function(function () {
  $e = error_get_last();
  if ($e && in_array($e['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) logx('FATAL ' . $e['message'] . ' @' . $e['file'] . ':' . $e['line']);
});
set_error_handler(function ($no, $str, $file, $line) { logx("WARN $str @$line"); return true; });

/* ---------- آیتم‌ها (c = عنوان روی کارت) ---------- */
$ITEMS = [
  'usd'   => ['src'=>'iran','key'=>'price_dollar_rl','unit'=>'rial','t'=>'دلار آمریکا','e'=>'🇺🇸','c'=>'USD / IRT','a'=>['دلار','usd','dollar']],
  'eur'   => ['src'=>'iran','key'=>'price_eur','unit'=>'rial','t'=>'یورو','e'=>'🇪🇺','c'=>'EUR / IRT','a'=>['یورو','eur','euro']],
  'gbp'   => ['src'=>'iran','key'=>'price_gbp','unit'=>'rial','t'=>'پوند انگلیس','e'=>'🇬🇧','c'=>'GBP / IRT','a'=>['پوند','gbp']],
  'aed'   => ['src'=>'iran','key'=>'price_aed','unit'=>'rial','t'=>'درهم امارات','e'=>'🇦🇪','c'=>'AED / IRT','a'=>['درهم','aed']],
  'try'   => ['src'=>'iran','key'=>'price_try','unit'=>'rial','t'=>'لیر ترکیه','e'=>'🇹🇷','c'=>'TRY / IRT','a'=>['لیر','try']],
  'gold18'=> ['src'=>'iran','key'=>'geram18','unit'=>'rial','t'=>'طلای ۱۸ عیار (هر گرم)','e'=>'🥇','c'=>'GOLD 18K / GRAM','a'=>['طلا','طلا18','طلای18','gold']],
  'coin'  => ['src'=>'iran','key'=>'sekee','unit'=>'rial','t'=>'سکه امامی','e'=>'🪙','c'=>'EMAMI COIN','a'=>['سکه','سکه امامی','coin']],
  'ons'   => ['src'=>'iran','key'=>'ons','unit'=>'usd','t'=>'اونس طلا','e'=>'🏆','c'=>'GOLD / OUNCE','a'=>['اونس','ons']],
  'brent' => ['src'=>'iran','key'=>'oil_brent','unit'=>'usd','t'=>'نفت برنت','e'=>'🛢','c'=>'BRENT OIL','a'=>['نفت','برنت','brent','oil']],
  'btc'   => ['src'=>'crypto','id'=>'bitcoin','t'=>'بیت‌کوین','e'=>'₿','c'=>'BTC / USD','a'=>['بیتکوین','بیت کوین','btc','bitcoin']],
  'eth'   => ['src'=>'crypto','id'=>'ethereum','t'=>'اتریوم','e'=>'⟠','c'=>'ETH / USD','a'=>['اتریوم','eth','ethereum']],
  'usdt'  => ['src'=>'crypto','id'=>'tether','t'=>'تتر','e'=>'💵','c'=>'USDT / USD','a'=>['تتر','usdt','tether']],
  'ton'   => ['src'=>'crypto','id'=>'the-open-network','t'=>'تون‌کوین','e'=>'💎','c'=>'TON / USD','a'=>['تون','ton','تون کوین']],
  'trx'   => ['src'=>'crypto','id'=>'tron','t'=>'ترون','e'=>'🔺','c'=>'TRX / USD','a'=>['ترون','trx','tron']],
  'sol'   => ['src'=>'crypto','id'=>'solana','t'=>'سولانا','e'=>'◎','c'=>'SOL / USD','a'=>['سولانا','sol','solana']],
  'bnb'   => ['src'=>'crypto','id'=>'binancecoin','t'=>'بایننس‌کوین','e'=>'🟡','c'=>'BNB / USD','a'=>['بی ان بی','bnb']],
  'xrp'   => ['src'=>'crypto','id'=>'ripple','t'=>'ریپل','e'=>'✖️','c'=>'XRP / USD','a'=>['ریپل','xrp']],
  'doge'  => ['src'=>'crypto','id'=>'dogecoin','t'=>'دوج‌کوین','e'=>'🐶','c'=>'DOGE / USD','a'=>['دوج','doge','dogecoin']],
  'sekeb' => ['src'=>'iran','key'=>'sekeb','unit'=>'rial','t'=>'سکه بهار آزادی','e'=>'🪙','c'=>'BAHAR AZADI COIN','a'=>['سکه بهار آزادی','بهار آزادی','سکه طرح جدید','سکه جدید','sekeb']],
  'nim'   => ['src'=>'iran','key'=>'nim','unit'=>'rial','t'=>'نیم‌سکه','e'=>'🪙','c'=>'HALF COIN','a'=>['نیم سکه','نیم‌سکه','نیم','nim']],
  'rob'   => ['src'=>'iran','key'=>'rob','unit'=>'rial','t'=>'ربع‌سکه','e'=>'🪙','c'=>'QUARTER COIN','a'=>['ربع سکه','ربع‌سکه','ربع','rob']],
  'gerami'=> ['src'=>'iran','key'=>'gerami','unit'=>'rial','t'=>'سکه گرمی','e'=>'🪙','c'=>'GRAM COIN','a'=>['سکه گرمی','گرمی','gerami']],
  'gold24'=> ['src'=>'iran','key'=>'geram24','unit'=>'rial','t'=>'طلای ۲۴ عیار (هر گرم)','e'=>'🥇','c'=>'GOLD 24K / GRAM','a'=>['طلا24','طلای24','طلا 24','طلای 24','طلای 24 عیار','gold24']],
  'mesghal'=>['src'=>'iran','key'=>'mesghal','unit'=>'rial','t'=>'مثقال طلا','e'=>'🥇','c'=>'GOLD MITHQAL','a'=>['مثقال','مثقال طلا','mesghal']],
  'silver'=> ['src'=>'iran','key'=>'silver_999','unit'=>'rial','t'=>'نقره ۹۹۹ (هر گرم)','e'=>'🥈','c'=>'SILVER 999 / GRAM','a'=>['نقره','نقره 999','silver']],
  'ada'   => ['src'=>'crypto','id'=>'cardano','t'=>'کاردانو','e'=>'🔵','c'=>'ADA / USD','a'=>['کاردانو','ada','cardano']],
  'avax'  => ['src'=>'crypto','id'=>'avalanche-2','t'=>'آوالانچ','e'=>'🔺','c'=>'AVAX / USD','a'=>['آوالانچ','avax']],
  'dot'   => ['src'=>'crypto','id'=>'polkadot','t'=>'پولکادات','e'=>'⚪','c'=>'DOT / USD','a'=>['پولکادات','dot','polkadot']],
  'shib'  => ['src'=>'crypto','id'=>'shiba-inu','t'=>'شیبا','e'=>'🐕','c'=>'SHIB / USD','a'=>['شیبا','shib','shiba']],
  'link'  => ['src'=>'crypto','id'=>'chainlink','t'=>'چین‌لینک','e'=>'🔗','c'=>'LINK / USD','a'=>['چین لینک','link','chainlink']],
  'ltc'   => ['src'=>'crypto','id'=>'litecoin','t'=>'لایت‌کوین','e'=>'🪙','c'=>'LTC / USD','a'=>['لایت کوین','ltc','litecoin']],
  'pol'   => ['src'=>'crypto','id'=>'polygon-ecosystem-token','t'=>'پالیگان','e'=>'🟣','c'=>'POL / USD','a'=>['پالیگان','pol','matic','polygon']],
  'not'   => ['src'=>'crypto','id'=>'notcoin','t'=>'نات‌کوین','e'=>'🟡','c'=>'NOT / USD','a'=>['نات کوین','notcoin','not']],
  'pepe'  => ['src'=>'crypto','id'=>'pepe','t'=>'پپه','e'=>'🐸','c'=>'PEPE / USD','a'=>['پپه','pepe']],
  'near'  => ['src'=>'crypto','id'=>'near','t'=>'نیر','e'=>'🌐','c'=>'NEAR / USD','a'=>['نیر','near']],
  'atom'  => ['src'=>'crypto','id'=>'cosmos','t'=>'کازماس','e'=>'⚛️','c'=>'ATOM / USD','a'=>['کازماس','atom','cosmos']],
  'xlm'   => ['src'=>'crypto','id'=>'stellar','t'=>'استلار','e'=>'✨','c'=>'XLM / USD','a'=>['استلار','xlm','stellar']],
  'usdc'  => ['src'=>'crypto','id'=>'usd-coin','t'=>'یو‌اس‌دی‌کوین','e'=>'💲','c'=>'USDC / USD','a'=>['یو اس دی کوین','usdc']],
  'bch'   => ['src'=>'crypto','id'=>'bitcoin-cash','t'=>'بیت‌کوین کش','e'=>'🟢','c'=>'BCH / USD','a'=>['بیت کوین کش','bch']],
];
$SUMMARY = ['usd','eur','gold18','coin','brent','btc','eth','usdt'];
foreach ((cfg()['custom'] ?? []) as $x) {            // آیتم‌های دلخواهی که از پنل اضافه شده
  $ITEMS['x' . substr(md5((string)$x['key']), 0, 6)] = ['src'=>'iran','key'=>(string)$x['key'],'unit'=>(string)$x['unit'],'t'=>(string)$x['n'],
    'e'=>(string)($x['e'] ?? '📌'),'c'=>strtoupper((string)$x['key']),'a'=>[(string)$x['n'], (string)$x['key']]];
}

/* ---------- ابزارها ---------- */
function http(string $url, array $post = null): ?string {
  $ch = curl_init($url);
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>20, CURLOPT_FOLLOWLOCATION=>true,
    CURLOPT_USERAGENT=>'Mozilla/5.0 IranVitoChangeBot']);
  if ($post !== null) { curl_setopt($ch, CURLOPT_POST, true); curl_setopt($ch, CURLOPT_POSTFIELDS, $post); }
  $r = curl_exec($ch); curl_close($ch);
  return $r === false ? null : $r;
}
function cached(string $name, callable $fn, int $ttl = CACHE_TTL): ?array {
  $f = CACHE_DIR . '/' . md5($name) . '.json';
  if (is_file($f) && time() - filemtime($f) < $ttl) return json_decode(file_get_contents($f), true);
  $d = $fn();
  if ($d) { file_put_contents($f, json_encode($d)); return $d; }
  return is_file($f) ? json_decode(file_get_contents($f), true) : null;
}
function tg(string $method, array $params = []): ?array {
  $r = http("https://api.telegram.org/bot" . BOT_TOKEN . "/$method", $params);
  $j = $r ? json_decode($r, true) : null;
  if (!$j || empty($j['ok'])) logx("TG $method failed: " . substr((string)$r, 0, 300));
  return $j;
}
function norm(string $s): string {
  $s = str_replace(['ي','ك','‌','ـ'], ['ی','ک',' ',''], $s);
  $s = strtr($s, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
  return mb_strtolower(trim(preg_replace('/\s+/u', ' ', $s)));
}
function jdate(bool $short = false): string {
  [$gy,$gm,$gd] = array_map('intval', explode('-', date('Y-n-j')));
  $gdm = [0,31,59,90,120,151,181,212,243,273,304,334];
  $gy2 = $gm > 2 ? $gy + 1 : $gy;
  $days = 355666 + 365*$gy + intdiv($gy2+3,4) - intdiv($gy2+99,100) + intdiv($gy2+399,400) + $gd + $gdm[$gm-1];
  $jy = -1595 + 33*intdiv($days,12053); $days %= 12053;
  $jy += 4*intdiv($days,1461); $days %= 1461;
  if ($days > 365) { $jy += intdiv($days-1,365); $days = ($days-1) % 365; }
  if ($days < 186) { $jm = 1 + intdiv($days,31); $jd = 1 + $days % 31; }
  else { $jm = 7 + intdiv($days-186,30); $jd = 1 + ($days-186) % 30; }
  return $short ? sprintf('%04d/%02d/%02d  ·  %s', $jy, $jm, $jd, date('H:i'))
                : sprintf('%04d/%02d/%02d | %s', $jy, $jm, $jd, date('H:i:s'));
}
function n(float $v, int $d = 0): string { return number_format($v, $d); }
function dec(float $v): int { return $v < 1 ? 4 : ($v < 1000 ? 2 : 0); }

/* ---------- قیمت و تاریخچه ---------- */
function iranData(): ?array {
  return cached('iran', function () {
    $r = http(IRAN_API); $j = $r ? json_decode($r, true) : null;
    return $j['current'] ?? null;
  });
}
function cryptoBatch(): array {
  global $ITEMS;
  $d = cached('cgbatch', function () use ($ITEMS) {
    $ids = ['the-open-network']; foreach ($ITEMS as $it) if ($it['src'] === 'crypto') $ids[] = $it['id'];
    $r = http(CG . '/simple/price?ids=' . urlencode(implode(',', array_unique($ids))) . '&vs_currencies=usd&include_24hr_change=true');
    $j = $r ? json_decode($r, true) : null;
    return (is_array($j) && $j) ? $j : null;
  });
  return $d ?: [];
}
function cryptoData(string $id): ?array {
  $bt = cryptoBatch(); if (isset($bt[$id]['usd'])) return $bt[$id];
  return cached("cg_$id", function () use ($id) {
    $r = http(CG . '/simple/price?ids=' . urlencode($id) . '&vs_currencies=usd&include_24hr_change=true');
    $j = $r ? json_decode($r, true) : null;
    return $j[$id] ?? null;
  });
}
function histRecord(string $k, float $v): void {
  $f = CACHE_DIR . "/hist_$k.json"; $now = time();
  $h = is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : [];
  if ($h && $now - end($h)[0] < 300) return;           // هر ۵ دقیقه یک نقطه
  $h[] = [$now, $v];
  $h = array_values(array_filter($h, fn($p) => $now - $p[0] < 172800));
  if (count($h) > 600) $h = array_slice($h, -600);
  file_put_contents($f, json_encode($h), LOCK_EX);
}
/** @return array{toman?:float,usd?:float,chg:?float}|null */
function getPrice(array $it, string $k = ''): ?array {
  if ($it['src'] === 'iran') {
    $row = iranData()[$it['key']] ?? null;
    if (!$row) return null;
    $p = (float) str_replace(',', '', (string)($row['p'] ?? '0'));
    if ($p <= 0) return null;
    $c = isset($row['dp']) ? (float) $row['dp'] : null;
    if ($c !== null && ($row['dt'] ?? '') === 'low') $c = -abs($c);
    $r = $it['unit'] === 'rial' ? ['toman'=>$p/10, 'chg'=>$c] : ['usd'=>$p, 'chg'=>$c];
    if ($k) histRecord($k, $r['toman'] ?? $r['usd']);
    return $r;
  }
  $d = cryptoData($it['id']); if (!$d) return null;
  $rate = iranData()['price_dollar_rl']['p'] ?? null;
  $toman = $rate ? $d['usd'] * ((float) str_replace(',', '', (string)$rate)) / 10 : null;
  return ['usd'=>(float)$d['usd'], 'toman'=>$toman, 'chg'=>$d['usd_24h_change'] ?? null];
}
function series(string $k): array {
  global $ITEMS; $it = $ITEMS[$k];
  if ($it['src'] === 'crypto') {
    $d = cached('cgc_' . $it['id'], function () use ($it) {
      $r = http(CG . '/coins/' . $it['id'] . '/market_chart?vs_currency=usd&days=1');
      $j = $r ? json_decode($r, true) : null;
      return isset($j['prices']) ? ['p'=>array_column($j['prices'], 1)] : null;
    }, 300);
    return array_map('floatval', $d['p'] ?? []);
  }
  $f = CACHE_DIR . "/hist_$k.json"; if (!is_file($f)) return [];
  $h = json_decode((string)file_get_contents($f), true) ?: [];
  $now = time();
  $h = array_filter($h, fn($p) => $now - $p[0] < 86400);
  return array_map('floatval', array_column(array_values($h), 1));
}
function resample(array $s, int $n): array {
  $c = count($s); if ($c <= $n) return $s;
  $o = [];
  for ($i = 0; $i < $n; $i++) {
    $a = (int) floor($i * $c / $n); $b = max($a + 1, (int) floor(($i + 1) * $c / $n));
    $seg = array_slice($s, $a, $b - $a); $o[] = array_sum($seg) / count($seg);
  }
  $o[$n - 1] = end($s);
  return $o;
}
function smooth(array $s): array {
  $c = count($s); if ($c < 4) return $s; $o = $s;
  for ($i = 1; $i < $c - 1; $i++) $o[$i] = ($s[$i-1] + $s[$i] + $s[$i+1]) / 3;
  return $o;
}


/** کندل روزانه از tgju (برای دلار، طلا، سکه، نفت و ...) */
function tgjuDaily(string $key, string $unit): array {
  $d = cached('tgd_' . $key, function () use ($key) {
    $r = http('https://api.tgju.org/v1/market/indicator/summary-table-data/' . $key);
    $j = $r ? json_decode($r, true) : null;
    return (is_array($j) && !empty($j['data']) && is_array($j['data'])) ? ['rows'=>$j['data']] : null;
  }, 3600);
  $out = [];
  foreach ($d['rows'] ?? [] as $row) {
    if (!is_array($row)) continue;
    $nums = []; $date = null;
    foreach ($row as $cell) {
      $t = trim(strip_tags((string)$cell));
      if (preg_match('#^\d{4}/\d{2}/\d{2}$#', $t)) { $date = $date ?? $t; continue; }
      $v = str_replace(',', '', $t);
      if (is_numeric($v)) $nums[] = (float)$v;
    }
    if (count($nums) < 4 || $nums[0] <= 0) continue;
    [$o, $x, $y, $c] = $nums;                       // ترتیب: باز، کم‌ترین، بیشترین، پایانی (جابجایی high/low خودکار اصلاح می‌شود)
    $f = $unit === 'rial' ? 0.1 : 1.0;
    $out[] = ['d'=>$date, 'v'=>[$o*$f, max($o,$x,$y,$c)*$f, min($o,$x,$y,$c)*$f, $c*$f]];
  }
  if (count($out) < 2) return [];
  if ($out[0]['d'] !== null && end($out)['d'] !== null && $out[0]['d'] > end($out)['d']) $out = array_reverse($out);
  return array_slice(array_column($out, 'v'), -40);
}
/** کندل‌ها: [ [[open,high,low,close],...], 'بازه' ] */
function candles(string $k): array {
  global $ITEMS; $it = $ITEMS[$k];
  if ($it['src'] === 'crypto') {
    $d = cached('cgo_' . $it['id'], function () use ($it) {
      $r = http(CG . '/coins/' . $it['id'] . '/ohlc?vs_currency=usd&days=1');
      $j = $r ? json_decode($r, true) : null;
      return (is_array($j) && $j && isset($j[0][4])) ? ['c'=>$j] : null;
    }, 300);
    $o = []; foreach ($d['c'] ?? [] as $r) $o[] = [(float)$r[1], (float)$r[2], (float)$r[3], (float)$r[4]];
    return [array_slice($o, -48), '30M'];
  }
  $f = CACHE_DIR . "/hist_$k.json"; $b = [];
  $h = is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : []; $now = time();
  foreach ($h as [$t, $v]) {
    if ($now - $t > 86400) continue;
    $key = intdiv((int)$t, 1800); $v = (float)$v;
    if (!isset($b[$key])) $b[$key] = [$v, $v, $v, $v];
    else { $b[$key][1] = max($b[$key][1], $v); $b[$key][2] = min($b[$key][2], $v); $b[$key][3] = $v; }
  }
  ksort($b); $local = array_slice(array_values($b), -48);
  if (count($local) >= 12) return [$local, '30M'];       // اگر کرون داده کافی جمع کرده
  $daily = tgjuDaily($it['key'], $it['unit']);
  if (count($daily) >= 5) return [$daily, '1D'];
  return [$local, '30M'];
}

/* ---------- رسم کارت (GD) ---------- */
function col($im, array $c, float $op = 1.0): int {
  return imagecolorallocatealpha($im, (int)$c[0], (int)$c[1], (int)$c[2], (int) round(127 * (1 - $op)));
}
function cadv(float $px, string $font, string $c): float {
  $sz = $px * FSCALE;
  $a = imagettfbbox($sz, 0, $font, '|' . $c . '|'); $b = imagettfbbox($sz, 0, $font, '||');
  return ($a[2] - $a[0]) - ($b[2] - $b[0]);
}
function tw(float $px, string $font, string $t, float $sp = 0): float {
  if (!$sp) { $b = imagettfbbox($px * FSCALE, 0, $font, $t); return $b[2] - $b[0]; }
  $w = 0; foreach (preg_split('//u', $t, -1, PREG_SPLIT_NO_EMPTY) as $c) $w += cadv($px, $font, $c) + $sp;
  return $w - $sp;
}
function tx($im, float $px, string $font, int $color, float $x, float $y, string $t, float $sp = 0, string $al = 'l'): float {
  $w = tw($px, $font, $t, $sp);
  if ($al === 'r') $x -= $w; elseif ($al === 'c') $x -= $w / 2;
  if (!$sp) { imagettftext($im, $px * FSCALE, 0, (int)round($x), (int)round($y), $color, $font, $t); return $w; }
  foreach (preg_split('//u', $t, -1, PREG_SPLIT_NO_EMPTY) as $c) {
    imagettftext($im, $px * FSCALE, 0, (int)round($x), (int)round($y), $color, $font, $c);
    $x += cadv($px, $font, $c) + $sp;
  }
  return $w;
}
function poly($im, array $pts, int $color): void {
  if (PHP_VERSION_ID >= 80000) imagefilledpolygon($im, $pts, $color);
  else imagefilledpolygon($im, $pts, intdiv(count($pts), 2), $color);
}
function thick($im, array $pts, float $w, int $color): void {
  $r = $w / 2;
  for ($i = 0; $i < count($pts) - 1; $i++) {
    [$x1, $y1] = $pts[$i]; [$x2, $y2] = $pts[$i + 1];
    $dx = $x2 - $x1; $dy = $y2 - $y1; $l = sqrt($dx * $dx + $dy * $dy); if ($l < 0.01) continue;
    $nx = -$dy / $l * $r; $ny = $dx / $l * $r;
    poly($im, [(int)round($x1+$nx),(int)round($y1+$ny),(int)round($x2+$nx),(int)round($y2+$ny),
               (int)round($x2-$nx),(int)round($y2-$ny),(int)round($x1-$nx),(int)round($y1-$ny)], $color);
  }
  foreach ($pts as [$x, $y]) imagefilledellipse($im, (int)round($x), (int)round($y), (int)$w, (int)$w, $color);
}
function rrect($im, float $x1, float $y1, float $x2, float $y2, float $r, int $c): void {
  $x1 = (int)$x1; $y1 = (int)$y1; $x2 = (int)$x2; $y2 = (int)$y2; $r = (int)$r;
  imagefilledrectangle($im, $x1 + $r, $y1, $x2 - $r, $y2, $c);
  imagefilledrectangle($im, $x1, $y1 + $r, $x2, $y2 - $r, $c);
  foreach ([[$x1+$r,$y1+$r],[$x2-$r,$y1+$r],[$x1+$r,$y2-$r],[$x2-$r,$y2-$r]] as [$cx, $cy])
    imagefilledellipse($im, $cx, $cy, 2 * $r, 2 * $r, $c);
}
function drawLine($im, array $ser, float $x0, float $x1, float $y0, float $y1, int $S, array $acc): void {
  $n = count($ser); $lo = min($ser); $hi = max($ser); $rng = ($hi - $lo) ?: 1; $pts = [];
  foreach ($ser as $i => $v) {
    $t = ($hi == $lo) ? 0.5 : ($v - $lo) / $rng;
    $pts[] = [$x0 + ($x1 - $x0) * $i / ($n - 1), $y1 - ($y1 - $y0) * 0.06 - ($y1 - $y0) * 0.88 * $t];
  }
  $lv = []; for ($i = 0; $i < 24; $i++) $lv[$i] = col($im, $acc, 0.27 * (1 - $i / 24));
  for ($x = (int)$x0; $x < (int)$x1; $x++) {
    $t = ($x - $x0) / ($x1 - $x0) * ($n - 1); $i = min((int)$t, $n - 2); $f = $t - $i;
    $y = $pts[$i][1] + ($pts[$i+1][1] - $pts[$i][1]) * $f; $hh = ($y1 - $y) / 24;
    for ($b = 0; $b < 24; $b++) imageline($im, $x, (int)($y + $b*$hh), $x, (int)($y + ($b+1)*$hh) + 1, $lv[$b]);
  }
  thick($im, $pts, 5*$S, col($im, $acc));
  [$ex, $ey] = end($pts);
  foreach ([[26,0.11],[16,0.24]] as [$r, $o]) imagefilledellipse($im, (int)$ex, (int)$ey, 2*$r*$S, 2*$r*$S, col($im, $acc, $o));
  imagefilledellipse($im, (int)$ex, (int)$ey, 18*$S, 18*$S, col($im, $acc));
  imagefilledellipse($im, (int)$ex, (int)$ey, 8*$S, 8*$S, imagecolorallocate($im, 10, 12, 16));
  imagefilledrectangle($im, (int)$x0, (int)($y1 + 18*$S), (int)$x1, (int)($y1 + 19*$S), col($im, [255,255,255], 0.07));
}
function drawCandles($im, array $cd, float $x0, float $x1, float $y0, float $y1, int $S, array $acc, float $cur): void {
  $x1 -= 168 * $S;                                   // جای قیمت‌های کنار نمودار
  $lo = min(array_column($cd, 2)); $hi = max(array_column($cd, 1));
  if ($hi - $lo < 1e-9) { $lo -= abs($lo) * 0.005 + 1e-6; $hi += abs($hi) * 0.005 + 1e-6; }
  $pv = ($hi - $lo) * 0.06; $lo -= $pv; $hi += $pv;
  $Y = fn(float $v): float => $y1 - ($v - $lo) / ($hi - $lo) * ($y1 - $y0);
  $grid = col($im, [255,255,255], 0.07); $lab = col($im, [92,99,112]);
  for ($i = 0; $i <= 4; $i++) {                      // خطوط شبکه + قیمت‌ها
    $v = $hi - ($hi - $lo) * $i / 4; $y = (int) round($Y($v));
    imagefilledrectangle($im, (int)$x0, $y, (int)$x1, $y + $S - 1, $grid);
    tx($im, 19*$S, FONT_M, $lab, $x1 + 16*$S, $y + 7*$S, n($v, dec($hi)));
  }
  $m = count($cd); $slot = ($x1 - $x0) / $m; $bw = max(3 * $S, (int)($slot * 0.6));
  $cu = col($im, [61,220,151]); $cdn = col($im, [255,107,107]);
  foreach ($cd as $i => [$o, $h, $l, $c]) {
    $cx = (int) round($x0 + $slot * ($i + 0.5)); $color = $c >= $o ? $cu : $cdn;
    imagefilledrectangle($im, $cx - $S, (int)round($Y($h)), $cx + $S - 1, (int)round($Y($l)), $color);
    $yo = (int)round($Y($o)); $yc = (int)round($Y($c)); $t = min($yo, $yc); $b = max($yo, $yc);
    if ($b - $t < 2 * $S) $b = $t + 2 * $S;
    imagefilledrectangle($im, (int)($cx - $bw / 2), $t, (int)($cx + $bw / 2), $b, $color);
  }
  $yl = (int) round($Y($cur)); $dash = col($im, $acc, 0.55);   // خط و برچسب آخرین قیمت
  for ($x = (int)$x0; $x < (int)$x1; $x += 12 * $S) imagefilledrectangle($im, $x, $yl, min($x + 6*$S, (int)$x1), $yl + $S - 1, $dash);
  $tag = n($cur, dec($hi)); $tgw = tw(19*$S, FONT_B, $tag); $tx0 = (int)($x1 + 8 * $S); $th = 34 * $S;
  rrect($im, $tx0, $yl - $th / 2, $tx0 + $tgw + 20 * $S, $yl + $th / 2, 8 * $S, imagecolorallocate($im, $acc[0], $acc[1], $acc[2]));
  tx($im, 19*$S, FONT_B, imagecolorallocate($im, 10, 12, 16), $tx0 + 10 * $S, $yl + 7 * $S, $tag);
}
function renderCard(string $k): ?string {
  global $ITEMS;
  if (!function_exists('imagettftext') || !is_file(FONT_B) || !is_file(FONT_M)) return null;
  @ini_set('memory_limit', '256M');
  $it = $ITEMS[$k]; $p = getPrice($it, $k); if (!$p) return null;
  $W = 1080; $H = 720; $S = 2;
  $cur = (float) ($p['toman'] ?? $p['usd']);

  if ($it['src'] === 'crypto')      { $big = n($p['usd'], dec($p['usd'])); $unit = 'USD'; $sub = isset($p['toman']) ? '≈ ' . n($p['toman']) . ' TOMAN' : ''; }
  elseif (isset($p['toman']))       { $big = n($p['toman']); $unit = 'TOMAN'; $sub = ''; }
  else                              { $big = n($p['usd'], dec($p['usd'])); $unit = 'USD'; $sub = ''; }
  if ($it['src'] === 'crypto') $cur = (float) $p['usd'];

  // داده چارت: کندل یا (در نبود داده کافی) خطی
  [$cd, $tf] = CHART_STYLE === 'candle' ? candles($k) : [[], ''];
  $useCandle = count($cd) >= 3;
  $ser = [];
  if ($useCandle) {
    $m = count($cd) - 1;
    $cd[$m][3] = $cur; $cd[$m][1] = max($cd[$m][1], $cur); $cd[$m][2] = min($cd[$m][2], $cur);
  } else {
    $ser = series($k);
    if (count($ser) < 2) $ser = [$cur, $cur];
    $ser = smooth(resample($ser, 96));
  }
  $first = $useCandle ? $cd[0][0] : $ser[0];
  $chg = $p['chg'] ?? (($first != 0) ? ($cur / $first - 1) * 100 : 0.0);
  $up = $chg >= 0;
  $acc = $up ? [61,220,151] : [255,107,107];
  $muted = [122,130,145];

  $im = imagecreatetruecolor($W * $S, $H * $S);
  imagealphablending($im, true);
  for ($y = 0; $y < $H * $S; $y++) {
    $t = $y / ($H * $S);
    imageline($im, 0, $y, $W * $S, $y, imagecolorallocate($im, (int)(10 + 6*$t), (int)(12 + 7*$t), (int)(16 + 10*$t)));
  }
  $gc = col($im, [$acc[0]*0.18, $acc[1]*0.18, $acc[2]*0.18], 0.04);
  for ($i = 0; $i < 48; $i++) {
    $r = 640 * $S * (1 - $i / 48);
    imagefilledellipse($im, (int)($W*$S*0.88), (int)(-$H*$S*0.08), (int)(2*$r), (int)(2*$r), $gc);
  }
  $pad = 76 * $S;
  $cw = tx($im, 28*$S, FONT_M, col($im, $muted), $pad, 128*$S, $it['c'], 5*$S);
  if ($useCandle) tx($im, 22*$S, FONT_M, col($im, [82,89,102]), $pad + $cw + 24*$S, 128*$S, $tf, 3*$S);
  $label = sprintf('%+.2f%%', $chg);
  $lw = tw(30*$S, FONT_B, $label); $ph = 56*$S; $pw = $lw + 44*$S; $py = 88*$S; $px2 = $W*$S - $pad;
  $pill = imagecolorallocate($im, (int)(14 + $acc[0]*0.15), (int)(16 + $acc[1]*0.15), (int)(22 + $acc[2]*0.15));
  rrect($im, $px2 - $pw, $py, $px2, $py + $ph, $ph / 2, $pill);
  tx($im, 30*$S, FONT_B, col($im, $acc), $px2 - $pw/2, $py + $ph/2 + 11*$S, $label, 0, 'c');
  $maxw = $W*$S - 2*$pad; $bs = 148 * $S;
  while ($bs > 80*$S && tw($bs, FONT_B, $big) + 26*$S + tw(32*$S, FONT_M, $unit, 4*$S) > $maxw) $bs -= 4*$S;
  $w = tx($im, $bs, FONT_B, col($im, [244,246,250]), $pad, 300*$S, $big);
  tx($im, 32*$S, FONT_M, col($im, $muted), $pad + $w + 26*$S, 300*$S, $unit, 4*$S);
  if ($sub) tx($im, 28*$S, FONT_M, col($im, $muted), $pad, 352*$S, $sub, 2*$S);

  $cy0 = ($sub ? 396 : 378) * $S; $cy1 = 596 * $S;
  if ($useCandle) drawCandles($im, $cd, $pad, $W*$S - $pad, $cy0, $cy1, $S, $acc, $cur);
  else            drawLine($im, $ser, $pad, $W*$S - $pad, $cy0, $cy1, $S, $acc);

  $dim = col($im, [92,99,112]);
  tx($im, 22*$S, FONT_M, $dim, $pad, ($H - 52) * $S, 'IRANVITO CHANGE', 4*$S);
  tx($im, 22*$S, FONT_M, $dim, $W*$S - $pad, ($H - 52) * $S, jdate(true), 2*$S, 'r');

  $out = imagecreatetruecolor($W, $H);
  imagecopyresampled($out, $im, 0, 0, 0, 0, $W, $H, $W * $S, $H * $S);
  $path = CACHE_DIR . '/card_' . uniqid() . '.png';
  imagepng($out, $path, 6);
  imagedestroy($im); imagedestroy($out);
  return $path;
}

/* ---------- مینی‌اپ: آدرس و API ---------- */
function appUrl(): string {
  $dir = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
  return 'https://' . ($_SERVER['HTTP_HOST'] ?? '') . $dir . '/miniapp.html';
}
function apiPrices(): array {
  global $ITEMS;
  $gold = ['gold18','gold24','coin','sekeb','nim','rob','gerami','mesghal','ons','silver'];
  $ut = usdToman(); $items = [];
  foreach ($ITEMS as $k => $it) {
    $p = getPrice($it, $k); if (!$p) continue;
    $g = $it['src'] === 'crypto' ? 'crypto' : (in_array($k, $gold, true) ? 'gold' : ($k === 'brent' ? 'oil' : (in_array($k, ['usd','eur','gbp','aed','try'], true) ? 'cur' : 'other')));
    $items[] = ['k'=>$k, 'n'=>$it['t'], 'c'=>$it['c'], 'e'=>$it['e'], 'g'=>$g,
      'toman'=>isset($p['toman']) ? round((float)$p['toman'], 2) : null, 'usd'=>isset($p['usd']) ? round((float)$p['usd'], 6) : null,
      'chg'=>$p['chg'] !== null ? round((float)$p['chg'], 2) : null];
  }
  $world = [];
  foreach (worldData() as $code => $w) {
    $p = worldPrice($code); if (!$p) continue;
    $world[] = ['code'=>$code, 'n'=>$w['n'], 'f'=>flagEmoji($w['iso']), 'toman'=>round($p['toman'], 4), 'per'=>round($p['per_usd'], 4)];
  }
  return ['ts'=>time(), 'usd_toman'=>$ut, 'items'=>$items, 'world'=>$world];
}
function apiChart(string $k): array {
  global $ITEMS; if (!isset($ITEMS[$k])) return ['ok'=>false];
  [$cd, $tf] = candles($k);
  return ['ok'=>count($cd) >= 2, 'tf'=>$tf, 'c'=>$cd];
}

/* ---------- پیام‌ها ---------- */
function card(string $k): string {
  global $ITEMS; $it = $ITEMS[$k]; $p = getPrice($it, $k);
  if (!$p) return tt('unavailable', ['t'=>$it['t']]);
  $lines = '';
  if (isset($p['toman'])) $lines .= "💰 <b>" . n($p['toman']) . "</b> تومان\n";
  if (isset($p['usd']))   $lines .= "💲 <b>" . n($p['usd'], dec($p['usd'])) . "</b> دلار\n";
  if ($p['chg'] !== null) $lines .= ($p['chg'] >= 0 ? '📈 +' : '📉 ') . n($p['chg'], 2) . "%\n";
  return tt('card_tpl', ['e'=>$it['e'], 't'=>$it['t'], 'lines'=>rtrim($lines), 'date'=>jdate()]);
}
function summary(): string {
  global $ITEMS, $SUMMARY; $o = tt('summary_title') . "\n\n";
  foreach ($SUMMARY as $k) {
    $it = $ITEMS[$k]; $p = getPrice($it, $k); if (!$p) continue;
    $v = isset($p['toman']) ? n($p['toman']) . ' تومان' : n($p['usd'], 2) . ' دلار';
    $o .= "{$it['e']} {$it['t']}: <b>$v</b> " . ($p['chg'] !== null ? '(' . ($p['chg']>=0?'+':'') . n($p['chg'],2) . '%)' : '') . "\n";
  }
  return $o . "\n🕒 " . jdate() . "\n🤖 " . tt('brand');
}
function findItem(string $text): ?string {
  global $ITEMS;
  $t = ltrim(norm($text), '/'); $t = preg_replace('/@' . preg_quote(strtolower(BOT_USER), '/') . '$/', '', $t);
  $t = preg_replace('/^(قیمت|نرخ)\s+/u', '', $t);
  foreach ($ITEMS as $k => $it) foreach ($it['a'] as $a) if (norm($a) === $t) return $k;
  return null;
}

/* ---------- جلوگیری از پردازش دوباره‌ی یک آپدیت + جواب سریع به تلگرام ---------- */
function seenUpdate(int $id): bool {
  if ($id <= 0) return false;
  $fh = @fopen(DATA_DIR . '/seen.json', 'c+'); if (!$fh) return false;
  flock($fh, LOCK_EX);
  $ids = json_decode((string) stream_get_contents($fh), true) ?: [];
  $dup = in_array($id, $ids, true);
  if (!$dup) { $ids[] = $id; $ids = array_slice($ids, -300); ftruncate($fh, 0); rewind($fh); fwrite($fh, json_encode($ids)); }
  flock($fh, LOCK_UN); fclose($fh);
  return $dup;
}
function finishNow(): void {
  ignore_user_abort(true); @set_time_limit(120);
  if (function_exists('litespeed_finish_request')) { litespeed_finish_request(); return; }
  if (function_exists('fastcgi_finish_request')) { fastcgi_finish_request(); return; }
  header('Connection: close'); header('Content-Length: 0'); while (ob_get_level() > 0) @ob_end_flush(); @flush();
}

/* ---------- وبهوک و کرون ---------- */
if (isset($_GET['setup'])) {
  if ($_GET['setup'] !== SECRET) { http_response_code(403); exit('forbidden'); }
  $url = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'] . strtok($_SERVER['REQUEST_URI'], '?');
  header('Content-Type: text/plain; charset=utf-8');
  print_r(tg('setWebhook', ['url'=>$url, 'secret_token'=>SECRET, 'allowed_updates'=>json_encode(['message','callback_query'])]));
  print_r(tg('setMyCommands', ['commands'=>json_encode([
    ['command'=>'start','description'=>'شروع'], ['command'=>'prices','description'=>'قیمت لحظه‌ای بازار'], ['command'=>'menu','description'=>'منوی اصلی'], ['command'=>'menu','description'=>'منوی اصلی'], ['command'=>'panel','description'=>'پنل مدیریت'], ['command'=>'id','description'=>'آیدی عددی من']])]));
  print_r(tg('setChatMenuButton', ['menu_button'=>json_encode(['type'=>'web_app', 'text'=>'ایرانویتو چنج', 'web_app'=>['url'=>appUrl()]], JSON_UNESCAPED_UNICODE)]));
  exit;
}
if (isset($_GET['log'])) {
  if ($_GET['log'] !== SECRET) { http_response_code(403); exit('forbidden'); }
  header('Content-Type: text/plain; charset=utf-8');
  echo is_file(CACHE_DIR . '/error.log') ? file_get_contents(CACHE_DIR . '/error.log') : "(لاگ خالی است)";
  exit;
}
if (isset($_GET['debug'])) {            // تست رسم کارت در مرورگر
  if ($_GET['debug'] !== SECRET) { http_response_code(403); exit('forbidden'); }
  $k = $_GET['item'] ?? 'btc';
  try {
    if (!isset($ITEMS[$k])) throw new Exception('item نامعتبر');
    $png = renderCard($k);
    if (!$png) throw new Exception('renderCard null برگرداند (قیمت نیامد یا فونت/GD مشکل دارد)');
    header('Content-Type: image/png'); readfile($png); @unlink($png);
  } catch (Throwable $e) {
    header('Content-Type: text/plain; charset=utf-8');
    echo 'ERROR: ' . $e->getMessage() . ' @' . $e->getFile() . ':' . $e->getLine();
  }
  exit;
}
if (isset($_GET['check'])) {            // گزارش وضعیت همه آیتم‌ها
  if ($_GET['check'] !== SECRET) { http_response_code(403); exit('forbidden'); }
  header('Content-Type: text/plain; charset=utf-8');
  $d = iranData(); echo 'tgju: ' . ($d ? count($d) . " keys\n" : "FAILED\n");
  foreach ($ITEMS as $k => $it) {
    $p = getPrice($it, $k); [$cd, $tf] = candles($k);
    printf("%-7s price:%-4s candles:%-3d %s\n", $k, $p ? 'OK' : 'NO', count($cd), $tf);
  }
  if ($d) {
    echo "\n-- کلیدهای مشابه در tgju --\n";
    $m = array_filter(array_keys($d), fn($x) => preg_match('/brent|oil|ons|seke|nim|rob|gerami|geram|mesghal|gold|silver|copper|gas|tether|hav|nima|sana|price_/i', (string)$x));
    echo implode(', ', array_slice($m, 0, 150)) . "\n";
  }
  echo "\n-- نمونه پاسخ تاریخچه دلار --\n" . substr((string)http('https://api.tgju.org/v1/market/indicator/summary-table-data/price_dollar_rl'), 0, 400) . "\n";
  exit;
}
if (isset($_GET['cron'])) {            // ثبت تاریخچه قیمت‌ها برای چارت (هر ۱۰ دقیقه صدا بزن)
  if ($_GET['cron'] !== SECRET) { http_response_code(403); exit('forbidden'); }
  $c = 0; foreach ($ITEMS as $k => $it) if ($it['src'] === 'iran' && getPrice($it, $k)) $c++;
  $pu = prUpdateAll();                                  // بروزرسانی خودکار قیمت محصولات وابسته به ارز
  exit("ok $c products:$pu");
}

/* ---------- پردازش آپدیت ---------- */
if (isset($_GET['api'])) {                // API عمومی مینی‌اپ
  header('Content-Type: application/json; charset=utf-8'); header('Access-Control-Allow-Origin: *'); header('Cache-Control: no-store');
  try { $out = $_GET['api'] === 'chart' ? apiChart((string)($_GET['k'] ?? '')) : apiPrices(); }
  catch (Throwable $e) { logx('API ' . $e->getMessage() . ' @' . $e->getLine()); $out = ['error'=>true]; }
  echo json_encode($out, JSON_UNESCAPED_UNICODE); exit;
}
if (($_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN'] ?? '') !== SECRET) { http_response_code(403); exit; }
$u = json_decode(file_get_contents('php://input'), true);
if (!$u) exit;
if (seenUpdate((int)($u['update_id'] ?? 0))) exit;   // همان آپدیت قبلاً پردازش شده
finishNow();                                          // به تلگرام فوراً 200 بده تا دوباره نفرستد

// جلوگیری از پردازش تکراری: اگر تلگرام دیر جواب بگیرد همان آپدیت را دوباره می‌فرستد
$updId = (int)($u['update_id'] ?? 0);
if ($updId) {
  $fp = @fopen(DATA_DIR . '/seen.txt', 'c+');
  if ($fp && flock($fp, LOCK_EX)) {
    $seen = array_filter(explode(',', (string) stream_get_contents($fp)));
    if (in_array((string)$updId, $seen, true)) { flock($fp, LOCK_UN); fclose($fp); exit; }
    $seen[] = (string)$updId; $seen = array_slice($seen, -300);
    ftruncate($fp, 0); rewind($fp); fwrite($fp, implode(',', $seen)); fflush($fp); flock($fp, LOCK_UN); fclose($fp);
  }
}
// جواب فوری ۲۰۰ به تلگرام، ادامه کار در پس‌زمینه
ignore_user_abort(true); @set_time_limit(90);
if (function_exists('fastcgi_finish_request')) { echo 'ok'; fastcgi_finish_request(); }
elseif (function_exists('litespeed_finish_request')) { echo 'ok'; litespeed_finish_request(); }

if (isset($u['callback_query'])) {
  $cq = $u['callback_query']; $data = (string)($cq['data'] ?? ''); $uid = (int)($cq['from']['id'] ?? 0); $msg = $cq['message'] ?? null;
  if (strncmp($data, 'p:', 2) === 0) { handlePanelCb($cq, $data, $uid, $msg); exit; }
  if (strncmp($data, 'm:', 2) === 0) { handleMenuCb($cq, $data); exit; }
  if (strncmp($data, 'c:', 2) === 0) { handleCalcCb($cq, $data); exit; }
  if (strncmp($data, 'm:', 2) === 0) { handleMenuCb($cq, $data); exit; }
  $k = substr($data, 2);
  if (isset($ITEMS[$k]) && $msg) {
    @unlink(CACHE_DIR . '/' . md5($ITEMS[$k]['src'] === 'iran' ? 'iran' : 'cg_' . $ITEMS[$k]['id']) . '.json');
    $ids = ['chat_id'=>$msg['chat']['id'], 'message_id'=>$msg['message_id']];
    $cap = card($k);
    if (isset($msg['photo'])) {
      $png = renderCard($k);
      if ($png) {
        retryPlain(function (bool $emo) use ($ids, $cap, $png, $k) {
          return tg('editMessageMedia', $ids + ['media'=>json_encode(['type'=>'photo', 'media'=>'attach://card', 'caption'=>fin($cap, true, $emo), 'parse_mode'=>'HTML'], JSON_UNESCAPED_UNICODE),
            'card'=>new CURLFile($png, 'image/png', 'card.png'), 'reply_markup'=>kb($k)]);
        });
        @unlink($png);
      } else tg('editMessageCaption', $ids + ['caption'=>fin($cap), 'parse_mode'=>'HTML', 'reply_markup'=>kb($k)]);
    } else tg('editMessageText', $ids + ['text'=>fin($cap), 'parse_mode'=>'HTML', 'reply_markup'=>kb($k)]);
  }
  tg('answerCallbackQuery', ['callback_query_id'=>$cq['id']]);
  exit;
}

try {
$m = $u['message'] ?? null; if (!$m) exit;
$chat = $m['chat']['id']; $text = (string)($m['text'] ?? ''); $uid = (int)($m['from']['id'] ?? 0);
$private = ($m['chat']['type'] ?? '') === 'private';

if ($private && isAdmin($uid)) { $st = stGet($uid); if ($st && panelInput($m, $st, $uid)) exit; }   // ورودی‌های پنل
if ($text === '') exit;

$send = function (string $t, string $kk = '', string $buy = '') use ($chat, $m) {
  return retryPlain(function (bool $emo) use ($t, $kk, $buy, $chat, $m) {
    return tg('sendMessage', ['chat_id'=>$chat, 'text'=>fin($t, true, $emo), 'parse_mode'=>'HTML',
      'reply_to_message_id'=>$m['message_id'], 'reply_markup'=>kb($kk, $buy), 'disable_web_page_preview'=>'true']);
  });
};

$nt = ltrim(norm($text), '/');
$cmd = preg_replace('/@.*$/', '', explode(' ', $nt)[0]);
$isCmd = isset($text[0]) && $text[0] === '/';

if ($isCmd && $cmd === 'id') {
  tg('sendMessage', ['chat_id'=>$chat, 'text'=>"🆔 آیدی عددی شما: <code>$uid</code>", 'parse_mode'=>'HTML', 'reply_to_message_id'=>$m['message_id']]);
} elseif ($isCmd && $cmd === 'panel') {
  if (!$private) { $reply = '🔒 پنل فقط در چت خصوصی با ربات باز می‌شود.'; }
  elseif (OWNER_ID === 0) { $reply = "ابتدا آیدی عددی خود را در فایل config.php بگذارید:\n<code>const OWNER_ID = $uid;</code>"; }
  elseif (!isAdmin($uid)) { $reply = '⛔ شما دسترسی ندارید.'; }
  else { $reply = null; }
  if ($reply !== null) tg('sendMessage', ['chat_id'=>$chat, 'text'=>$reply, 'parse_mode'=>'HTML']);
  else { [$pt, $pr] = panelHome($uid); tg('sendMessage', ['chat_id'=>$chat, 'text'=>$pt, 'parse_mode'=>'HTML', 'reply_markup'=>pkb($pr)]); }
} elseif ($isCmd && $cmd === 'menu' && $private) {
  sendMenu((int)$chat, (int)$m['message_id'], $m['from'] ?? []);
} elseif ($isCmd && $cmd === 'app') {
  $appBtn = $private ? ['text'=>'🏛 باز کردن مینی‌اپ', 'web_app'=>['url'=>appUrl()]] : ['text'=>'🏛 باز کردن مینی‌اپ', 'url'=>'https://t.me/' . BOT_USER . '?start=app'];
  tg('sendMessage', ['chat_id'=>$chat, 'text'=>'🏛 مینی‌اپ <b>ایرانویتو چنج</b>', 'parse_mode'=>'HTML', 'reply_markup'=>json_encode(['inline_keyboard'=>[[$appBtn]]], JSON_UNESCAPED_UNICODE)]);
} elseif ($isCmd && $cmd === 'menu') {
  if ($private) sendMenu($chat, tt('menu_title'), (int)$m['message_id']);
  else $send(tt('menu_title'), '', '');
} elseif (preg_match('/^start/', $nt)) {
  if ($private && trim(substr($nt, 5)) === 'app') {
    tg('sendMessage', ['chat_id'=>$chat, 'text'=>'🏛 مینی‌اپ <b>ایرانویتو چنج</b>', 'parse_mode'=>'HTML', 'reply_markup'=>json_encode(['inline_keyboard'=>[[['text'=>'🏛 باز کردن مینی‌اپ', 'web_app'=>['url'=>appUrl()]]]]], JSON_UNESCAPED_UNICODE)]);
  } elseif ($private) { sendMenu($chat, tt('start'), (int)$m['message_id']);
  } elseif ($private) {
    sendMenu((int)$chat, (int)$m['message_id'], $m['from'] ?? []);
  } else $send(tt('start'));
} elseif (preg_match('/^(prices|قیمت ها|قیمت|بازار)(@.*)?$/u', $nt)) {
  $send(summary());
} elseif ($fk = fragKind($text)) {
  $send(fragText($fk), '', fragUrl($fk));
} elseif (calcTrigger($text)) {
  calcOpen((int)$chat, $uid, (int)$m['message_id']);
} elseif (($prt = prUserText($text)) !== null) {
  $send($prt);
} elseif (worldListTrigger($text)) {
  $send(worldTop());
} elseif ($key = (findItem($text) ?: worldItemKey($text, !$private))) {
  $png = renderCard($key);
  if ($png) {
    retryPlain(function (bool $emo) use ($chat, $m, $png, $key) {
      return tg('sendPhoto', ['chat_id'=>$chat, 'photo'=>new CURLFile($png, 'image/png', 'card.png'), 'caption'=>fin(card($key), true, $emo),
        'parse_mode'=>'HTML', 'reply_to_message_id'=>$m['message_id'], 'reply_markup'=>kb($key)]);
    });
    @unlink($png);
  } else {
    $send(card($key), $key);   // اگر GD/فونت نبود، فقط متن
  }
} elseif ($wc = worldLookup($text, !$private)) {
  $send(worldText($wc));
} elseif (($am = parseAmount($text)) !== null) {
  $send(amountText($am));
}
} catch (Throwable $e) { logx('EXC ' . $e->getMessage() . ' @' . $e->getFile() . ':' . $e->getLine()); }
