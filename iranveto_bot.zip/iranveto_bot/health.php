<?php
// بررسی سلامت نصب. آدرس: health.php?key=SECRET   (بعد از تست حتماً پاکش کن)
require __DIR__ . '/config.php';
if (($_GET['key'] ?? '') !== SECRET) { http_response_code(403); exit('forbidden'); }
header('Content-Type: text/plain; charset=utf-8');
$ok = fn(bool $b) => $b ? 'OK  ' : 'FAIL';
echo "PHP " . PHP_VERSION . "\n" . $ok(PHP_VERSION_ID >= 70400) . " PHP >= 7.4\n";
foreach (['curl', 'gd', 'mbstring', 'json'] as $e) echo $ok(extension_loaded($e)) . " ext-$e\n";
echo $ok(function_exists('imagettftext')) . " GD FreeType\n";
foreach (['bot.php','panel.php','pricing.php','calc.php','menu.php','world.php','config.php','fonts/Inter-Bold.otf','fonts/Inter-Medium.otf'] as $f)
  echo $ok(is_file(__DIR__ . "/$f")) . " file $f\n";
foreach (['data','cache'] as $d) {
  if (!is_dir(__DIR__ . "/$d")) @mkdir(__DIR__ . "/$d", 0755, true);
  echo $ok(is_dir(__DIR__ . "/$d") && is_writable(__DIR__ . "/$d")) . " writable $d/\n";
}
echo $ok(BOT_TOKEN !== 'PUT_YOUR_NEW_BOT_TOKEN' && strpos(BOT_TOKEN, ':') !== false) . " BOT_TOKEN set\n";
echo $ok(defined('OWNER_ID') && OWNER_ID !== 0) . " OWNER_ID set\n";
$r = @file_get_contents('https://api.telegram.org/bot' . BOT_TOKEN . '/getMe');
echo $ok($r !== false && strpos((string)$r, '"ok":true') !== false) . " Telegram getMe (outbound + token)\n";
echo "\nمرحله‌ی بعد: bot.php?setup=SECRET\n";
