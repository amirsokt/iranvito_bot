#!/usr/bin/env bash
# نصب خودکار ربات روی Ubuntu 22.04/24.04 (هتزنر)
# استفاده:  bash install.sh YOUR.DOMAIN you@email.com
set -euo pipefail
DOMAIN="${1:-}"; EMAIL="${2:-}"
[ "$(id -u)" -eq 0 ] || { echo "با root اجرا کن"; exit 1; }
[ -n "$DOMAIN" ] || { echo "مثال: bash install.sh bot.example.com you@email.com"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"; DEST=/var/www/bot

echo "== نصب پکیج‌ها"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y nginx php-fpm php-cli php-curl php-gd php-mbstring unzip curl certbot python3-certbot-nginx

echo "== کپی فایل‌ها"
mkdir -p "$DEST"
if [ "$SRC" != "$DEST" ]; then cp -rn "$DEST" "$DEST.bak.$(date +%s)" 2>/dev/null || true; cp -r "$SRC"/. "$DEST"/; fi
rm -f "$DEST/install.sh"
[ -f "$DEST/config.php" ] || { cp "$DEST/config.example.php" "$DEST/config.php"; echo "!! config.php ساخته شد؛ توکن و SECRET را پر کن: nano $DEST/config.php"; }
mkdir -p "$DEST/data" "$DEST/cache"
chown -R www-data:www-data "$DEST"; chmod 750 "$DEST/data" "$DEST/cache"; chmod 640 "$DEST/config.php"

echo "== بررسی نحو PHP"
for f in bot panel pricing calc; do php -l "$DEST/$f.php"; done
for f in menu world; do [ -f "$DEST/$f.php" ] && php -l "$DEST/$f.php" || echo "!! $f.php وجود ندارد (باید از هاست قبلی بیاوری)"; done

echo "== nginx"
SOCK="$(ls /run/php/php*-fpm.sock | head -n1)"
cat > /etc/nginx/sites-available/bot <<NGX
server {
  listen 80;
  server_name $DOMAIN;
  root $DEST;
  index bot.php;
  client_max_body_size 5m;
  location ~ ^/(data|cache|fonts)/ { deny all; }
  location = /config.php { deny all; }
  location ~ \.php\$ {
    include snippets/fastcgi-php.conf;
    fastcgi_pass unix:$SOCK;
  }
}
NGX
ln -sf /etc/nginx/sites-available/bot /etc/nginx/sites-enabled/bot
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo "== گواهی SSL (دامنه باید قبلاً با رکورد A به IP این سرور اشاره کند)"
if [ -n "$EMAIL" ]; then certbot --nginx -d "$DOMAIN" -m "$EMAIL" --agree-tos --no-eff-email --redirect -n || echo "!! certbot خطا داد؛ DNS را چک کن"
else echo "ایمیل ندادی؛ دستی بزن: certbot --nginx -d $DOMAIN"; fi

echo "== کرون (هر ۵ دقیقه)"
SECRET="$(php -r 'require "'"$DEST"'/config.php"; echo SECRET;' 2>/dev/null || true)"
if [ -n "$SECRET" ]; then
  ( crontab -u www-data -l 2>/dev/null | grep -v 'bot.php?cron=' ; echo "*/5 * * * * curl -s \"https://$DOMAIN/bot.php?cron=$SECRET\" >/dev/null" ) | crontab -u www-data -
fi

cat <<MSG

تمام شد. حالا:
 1) nano $DEST/config.php  ← توکن جدید، SECRET، OWNER_ID
 2) https://$DOMAIN/health.php?key=SECRET
 3) https://$DOMAIN/bot.php?setup=SECRET   (باید "ok":true ببینی)
 4) در تلگرام: /panel
 5) بعد از تست: rm $DEST/health.php
MSG
