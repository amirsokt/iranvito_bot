<?php
/**
 * پنل مدیریت داخل تلگرام: تبلیغات، رنگ دکمه‌ها، فونت، ویرایش متن‌ها،
 * ایموجی پرمیوم، قیمت فرگمنت و مدیریت ادمین‌ها
 */
declare(strict_types=1);

if (!defined('OWNER_ID')) define('OWNER_ID', 0);
const DATA_DIR = __DIR__ . '/data';
if (!is_dir(DATA_DIR)) { @mkdir(DATA_DIR, 0755, true); @file_put_contents(DATA_DIR . '/.htaccess', "Require all denied\nDeny from all\n"); }

/* ---------- تنظیمات ---------- */
function cfg(?array $new = null): array {
  static $c = null;
  if ($new !== null) { $c = $new; file_put_contents(DATA_DIR . '/settings.json', json_encode($c, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), LOCK_EX); return $c; }
  if ($c === null) {
    $f = DATA_DIR . '/settings.json';
    $c = is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : [];
    $def = [
      'admins' => [],
      'ad'     => ['on'=>false, 'text'=>'', 'btn_text'=>'', 'btn_url'=>''],
      'colors' => ['refresh'=>'default', 'group'=>'default', 'ad'=>'primary', 'sub'=>'default'],
      'font'   => 'normal',
      'texts'  => [],
      'emoji'  => [],
      'custom' => [],
      'menu'   => [],
      'menu'   => [],
      'frag'   => ['star_usd'=>0.016, 'p3'=>12.0, 'p6'=>16.0, 'p12'=>28.0, 'nft'=>[]],
    ];
    foreach ($def as $k => $v) {
      if (!isset($c[$k])) $c[$k] = $v;
      elseif (in_array($k, ['ad','colors','frag'], true)) $c[$k] = array_merge($v, $c[$k]);
    }
  }
  return $c;
}
function isOwner(int $id): bool { return OWNER_ID !== 0 && $id === (int)OWNER_ID; }
function cfgAdmins(): array { return defined('ADMIN_IDS') ? array_map('intval', (array)ADMIN_IDS) : []; }   // ادمین‌های تعریف‌شده در config.php
function isAdmin(int $id): bool { return isOwner($id) || in_array($id, cfgAdmins(), true) || in_array($id, array_map('intval', cfg()['admins']), true); }
function stFile(int $uid): string { return DATA_DIR . "/st_$uid.json"; }
function stGet(int $uid): array { $f = stFile($uid); return is_file($f) ? (json_decode((string)file_get_contents($f), true) ?: []) : []; }
function stSet(int $uid, array $s): void { file_put_contents(stFile($uid), json_encode($s)); }
function stClear(int $uid): void { @unlink(stFile($uid)); }

/* ---------- متن‌های قابل ویرایش ---------- */
function textDefaults(): array {
  return [
    'start' => "سلام 👋\nبه <b>{brand}</b> خوش اومدی!\n\nاسم هر ارز یا دارایی رو بفرست تا قیمتش رو با نمودار بگیری، مثل:\n<code>دلار</code> ، <code>یورو</code> ، <code>طلا</code> ، <code>سکه</code> ، <code>نفت</code> ، <code>بیتکوین</code> ، <code>تتر</code>\n\nقیمت فرگمنت: <code>استارز</code> ، <code>پریمیوم</code> ، <code>nft</code>\n\nبرای لیست کامل: /prices",
    'summary_title' => "📊 <b>قیمت لحظه‌ای بازار</b>",
    'unavailable' => "⚠️ فعلا قیمت {t} در دسترس نیست. کمی بعد دوباره امتحان کنید.",
    'card_tpl' => "{e} <b>1 {t}</b> :\n\n{lines}\n\n🕒 {date}\n\n🤖 {brand}",
    'brand' => BRAND,
    'btn_refresh' => '🔄 بروزرسانی',
    'btn_group' => '➕ افزودن به گروه',
    'frag_title' => "💎 <b>قیمت‌های فرگمنت تلگرام</b>",
    'stars_title' => "⭐ <b>Telegram Stars</b>",
    'premium_title' => "👑 <b>Telegram Premium</b>",
    'nft_title' => "🖼 <b>NFT و گیفت‌های تلگرام</b>",
    'menu_title' => "🧭 <b>منوی اصلی</b>\n\nیکی از بخش‌ها را انتخاب کنید:",
    'help' => "📖 <b>راهنما</b>\n\n• اسم هر ارز، طلا یا کریپتو را بنویسید: <code>دلار</code> ، <code>طلا</code> ، <code>بیتکوین</code>\n• نرخ کشورها: <code>ین</code> ، <code>ژاپن</code> ، <code>ارزهای جهان</code>\n• فرگمنت: <code>استارز</code> ، <code>پریمیوم</code> ، <code>nft</code>\n• در گروه‌ها قبل از نام کشور «نرخ» بنویسید: <code>نرخ ژاپن</code>\n• مینی‌اپ و ماشین‌حساب: /app",
  ];
}
/** key => [نام، راهنمای متغیرها، فقط متن ساده؟] */
function textMeta(): array {
  return [
    'start' => ['پیام شروع (/start)', '{brand}', false],
    'summary_title' => ['عنوان لیست قیمت‌ها (/prices)', '', false],
    'unavailable' => ['پیام نبودن قیمت', '{t}', false],
    'card_tpl' => ['قالب پیام قیمت', '{e} {t} {lines} {date} {brand}', false],
    'brand' => ['امضا / نام برند', '', false],
    'btn_refresh' => ['متن دکمه بروزرسانی', '', true],
    'btn_group' => ['متن دکمه افزودن به گروه', '', true],
    'frag_title' => ['عنوان صفحه فرگمنت (کلی)', '', false],
    'stars_title' => ['عنوان صفحه استارز', '', false],
    'premium_title' => ['عنوان صفحه پریمیوم', '', false],
    'nft_title' => ['عنوان صفحه NFT', '', false],
    'menu_title' => ['عنوان منوی اصلی (/menu)', '', false],
    'help' => ['متن راهنما', '', false],
  ];
}
function tt(string $key, array $vars = []): string {
  $c = cfg()['texts']; $d = textDefaults();
  $s = (string)($c[$key] ?? $d[$key] ?? '');
  $vars['brand'] = (string)($c['brand'] ?? $d['brand']);
  $r = []; foreach ($vars as $k => $v) $r['{' . $k . '}'] = (string)$v;
  return strtr($s, $r);
}

/* ---------- رنگ دکمه‌ها ----------
 * تلگرام فقط ۳ رنگ واقعی دارد (آبی/سبز/قرمز)، بقیه با ایموجی رنگی ساخته می‌شود */
function btnColors(): array {
  return [
    'default' => ['⚪ پیش‌فرض', '', ''],
    'primary' => ['🔵 آبی (رنگ واقعی)', 'primary', ''],
    'success' => ['🟢 سبز (رنگ واقعی)', 'success', ''],
    'danger'  => ['🔴 قرمز (رنگ واقعی)', 'danger', ''],
    'orange'  => ['🟠 نارنجی', '', '🟧'],
    'yellow'  => ['🟡 زرد', '', '🟨'],
    'purple'  => ['🟣 بنفش', '', '🟪'],
    'brown'   => ['🟤 قهوه‌ای', '', '🟫'],
    'black'   => ['⚫ مشکی', '', '⬛'],
    'white'   => ['⚪ سفید', '', '⬜'],
    'pink'    => ['🩷 صورتی', '', '🩷'],
    'sky'     => ['🩵 آبی روشن', '', '🩵'],
  ];
}
function mkBtn(string $text, string $target, array $extra): array {
  $all = btnColors(); $ck = cfg()['colors'][$target] ?? 'default'; $d = $all[$ck] ?? $all['default'];
  $b = ['text' => ($d[2] !== '' ? $d[2] . ' ' : '') . $text] + $extra;
  if ($d[1] !== '') $b['style'] = $d[1];
  return $b;
}
function kb(string $k = '', string $buy = ''): string {
  $rows = [];
  if ($k) $rows[] = [mkBtn(tt('btn_refresh'), 'refresh', ['callback_data' => "r:$k"])];
  $rows[] = [mkBtn('🧮 ماشین‌حساب', 'calc', ['callback_data' => 'c:open'])];
  if ($buy !== '') $rows[] = [mkBtn('🛒 خرید از Fragment', 'group', ['url' => $buy])];
  $rows[] = [mkBtn(tt('btn_group'), 'group', ['url' => 'https://t.me/' . BOT_USER . '?startgroup=true'])];
  $a = cfg()['ad'];
  if (!empty($a['on']) && (string)$a['btn_text'] !== '' && preg_match('#^(https?://|tg://)\S+$#', (string)$a['btn_url']))
    $rows[] = [mkBtn((string)$a['btn_text'], 'ad', ['url' => (string)$a['btn_url']])];
  return json_encode(['inline_keyboard' => $rows], JSON_UNESCAPED_UNICODE);
}

/* ---------- فونت (تبدیل حروف لاتین و اعداد به استایل‌های یونیکد) ---------- */
function fontStyles(): array {
  return [
    'normal'     => ['n'=>'Normal (عادی)'],
    'bold'       => ['n'=>'Bold', 'U'=>0x1D400, 'L'=>0x1D41A, 'D'=>0x1D7CE],
    'italic'     => ['n'=>'Italic', 'U'=>0x1D434, 'L'=>0x1D44E, 'ex'=>['h'=>'ℎ']],
    'bolditalic' => ['n'=>'Bold Italic', 'U'=>0x1D468, 'L'=>0x1D482],
    'script'     => ['n'=>'Script', 'U'=>0x1D49C, 'L'=>0x1D4B6, 'ex'=>['B'=>'ℬ','E'=>'ℰ','F'=>'ℱ','H'=>'ℋ','I'=>'ℐ','L'=>'ℒ','M'=>'ℳ','R'=>'ℛ','e'=>'ℯ','g'=>'ℊ','o'=>'ℴ']],
    'boldscript' => ['n'=>'Bold Script', 'U'=>0x1D4D0, 'L'=>0x1D4EA],
    'fraktur'    => ['n'=>'Fraktur', 'U'=>0x1D504, 'L'=>0x1D51E, 'ex'=>['C'=>'ℭ','H'=>'ℌ','I'=>'ℑ','R'=>'ℜ','Z'=>'ℨ']],
    'boldfraktur'=> ['n'=>'Bold Fraktur', 'U'=>0x1D56C, 'L'=>0x1D586],
    'double'     => ['n'=>'Double-Struck', 'U'=>0x1D538, 'L'=>0x1D552, 'D'=>0x1D7D8, 'ex'=>['C'=>'ℂ','H'=>'ℍ','N'=>'ℕ','P'=>'ℙ','Q'=>'ℚ','R'=>'ℝ','Z'=>'ℤ']],
    'sans'       => ['n'=>'Sans', 'U'=>0x1D5A0, 'L'=>0x1D5BA, 'D'=>0x1D7E2],
    'sansbold'   => ['n'=>'Sans Bold', 'U'=>0x1D5D4, 'L'=>0x1D5EE, 'D'=>0x1D7EC],
    'sansitalic' => ['n'=>'Sans Italic', 'U'=>0x1D608, 'L'=>0x1D622],
    'sansbi'     => ['n'=>'Sans Bold Italic', 'U'=>0x1D63C, 'L'=>0x1D656],
    'mono'       => ['n'=>'Monospace', 'U'=>0x1D670, 'L'=>0x1D68A, 'D'=>0x1D7F6],
    'wide'       => ['n'=>'Fullwidth', 'U'=>0xFF21, 'L'=>0xFF41, 'D'=>0xFF10],
    'circled'    => ['n'=>'Circled', 'U'=>0x24B6, 'L'=>0x24D0, 'digits'=>'⓪①②③④⑤⑥⑦⑧⑨'],
    'negcircled' => ['n'=>'Negative Circled', 'U'=>0x1F150, 'lower'=>'U', 'digits'=>'⓿❶❷❸❹❺❻❼❽❾'],
    'squared'    => ['n'=>'Squared', 'U'=>0x1F130, 'lower'=>'U'],
    'negsquared' => ['n'=>'Negative Squared', 'U'=>0x1F170, 'lower'=>'U'],
    'paren'      => ['n'=>'Parenthesized', 'U'=>0x1F110, 'L'=>0x249C],
    'smallcaps'  => ['n'=>'Small Caps', 'lowermap'=>'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ'],
    'super'      => ['n'=>'Superscript', 'lowermap'=>'ᵃᵇᶜᵈᵉᶠᵍʰⁱʲᵏˡᵐⁿᵒᵖᵠʳˢᵗᵘᵛʷˣʸᶻ', 'digits'=>'⁰¹²³⁴⁵⁶⁷⁸⁹'],
    'sub'        => ['n'=>'Subscript', 'digits'=>'₀₁₂₃₄₅₆₇₈₉'],
    'strike'     => ['n'=>'Strikethrough', 'comb'=>"\u{0336}"],
    'under'      => ['n'=>'Underline', 'comb'=>"\u{0332}"],
    'dblunder'   => ['n'=>'Double Underline', 'comb'=>"\u{0333}"],
    'over'       => ['n'=>'Overline', 'comb'=>"\u{0305}"],
    'slash'      => ['n'=>'Slash', 'comb'=>"\u{0338}"],
    'dots'       => ['n'=>'Dotted', 'comb'=>"\u{0307}"],
    'spaced'     => ['n'=>'S p a c e d', 'spaced'=>true],
  ];
}
function uchr(int $cp): string { return (string) mb_chr($cp, 'UTF-8'); }
function fontMap(string $key): array {
  static $cache = [];
  if (isset($cache[$key])) return $cache[$key];
  $s = fontStyles()[$key] ?? null; $m = [];
  if ($s) {
    foreach (range('A', 'Z') as $i => $ch) if (isset($s['U'])) $m[$ch] = $s['ex'][$ch] ?? uchr($s['U'] + $i);
    foreach (range('a', 'z') as $i => $ch) {
      if (isset($s['lowermap'])) $m[$ch] = (string) mb_substr($s['lowermap'], $i, 1);
      elseif (isset($s['L'])) $m[$ch] = $s['ex'][$ch] ?? uchr($s['L'] + $i);
      elseif (($s['lower'] ?? '') === 'U' && isset($s['U'])) $m[$ch] = uchr($s['U'] + $i);
    }
    if (isset($s['D'])) foreach (range(0, 9) as $d) $m[(string)$d] = uchr($s['D'] + $d);
    elseif (isset($s['digits'])) foreach (range(0, 9) as $d) $m[(string)$d] = (string) mb_substr($s['digits'], $d, 1);
  }
  return $cache[$key] = $m;
}
function fontText(string $s, string $key): string {
  if ($key === 'normal') return $s;
  $st = fontStyles()[$key] ?? null; if (!$st) return $s;
  $m = fontMap($key); $comb = $st['comb'] ?? null; $spaced = !empty($st['spaced']); $o = '';
  foreach (preg_split('//u', $s, -1, PREG_SPLIT_NO_EMPTY) as $ch) {
    if ($comb !== null)      $o .= ctype_alnum($ch) ? $ch . $comb : $ch;
    elseif ($spaced)         $o .= ctype_alpha($ch) ? $ch . ' ' : $ch;
    else                     $o .= $m[$ch] ?? $ch;
  }
  return $o;
}

/* ---------- تبلیغ + فونت + ایموجی پرمیوم روی خروجی ---------- */
function adSuffix(): string {
  $a = cfg()['ad'];
  return (!empty($a['on']) && trim((string)$a['text']) !== '') ? "\n\n" . $a['text'] : '';
}
function fin(string $html, bool $ad = true, bool $emo = true): string {
  if ($ad) $html .= adSuffix();
  $c = cfg(); $font = (string)$c['font']; $map = [];
  if ($emo) foreach ($c['emoji'] as $e => $id) if ($e !== '') $map[(string)$e] = '<tg-emoji emoji-id="' . $id . '">' . $e . '</tg-emoji>';
  if ($font === 'normal' && !$map) return $html;
  $out = ''; $skip = 0;
  foreach (preg_split('/(<[^>]*>|&#?\w+;)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE) as $p) {
    if ($p === '') continue;
    if ($p[0] === '<') {
      if (preg_match('#^<(code|pre|a|tg-emoji)\b#i', $p)) $skip++;
      elseif (preg_match('#^</(code|pre|a|tg-emoji)>#i', $p)) $skip = max(0, $skip - 1);
      $out .= $p; continue;
    }
    if ($p[0] === '&') { $out .= $p; continue; }
    if ($skip === 0) { $p = fontText($p, $font); if ($map) $p = strtr($p, $map); }
    $out .= $p;
  }
  return $out;
}
function retryPlain(callable $f): ?array {
  $r = $f(true);
  if ($r === null || !empty($r['ok']) || !cfg()['emoji']) return $r;       // اگر پاسخ نیامده (تایم‌اوت) دوباره نفرست تا پیام دوبل نشود
  return $f(false);                       // اگر تلگرام ایموجی پرمیوم را نپذیرفت، بدون آن بفرست
}

/* ---------- تبدیل فرمت پیام تلگرام (entities) به HTML ---------- */
function entTag(array $e): ?array {
  switch ($e['type'] ?? '') {
    case 'bold': return ['<b>', '</b>'];
    case 'italic': return ['<i>', '</i>'];
    case 'underline': return ['<u>', '</u>'];
    case 'strikethrough': return ['<s>', '</s>'];
    case 'spoiler': return ['<tg-spoiler>', '</tg-spoiler>'];
    case 'code': return ['<code>', '</code>'];
    case 'pre': return ['<pre>', '</pre>'];
    case 'blockquote': return ['<blockquote>', '</blockquote>'];
    case 'text_link': return ['<a href="' . htmlspecialchars((string)$e['url']) . '">', '</a>'];
    case 'custom_emoji': return ['<tg-emoji emoji-id="' . $e['custom_emoji_id'] . '">', '</tg-emoji>'];
  }
  return null;
}
function entHtml(string $text, array $ents): string {
  $u = mb_convert_encoding($text, 'UTF-16LE', 'UTF-8'); $len = intdiv(strlen($u), 2);
  $starts = []; $ends = []; $pos = [0, $len];
  foreach ($ents as $i => $e) {
    $t = entTag($e); if (!$t) continue;
    $a = (int)$e['offset']; $b = min($len, $a + (int)$e['length']);
    $starts[$a][] = [$i, $b, $t[0]]; $ends[$b][] = [$i, $a, $t[1]]; $pos[] = $a; $pos[] = $b;
  }
  $pos = array_values(array_unique($pos)); sort($pos); $out = '';
  foreach ($pos as $n => $p) {
    if (isset($ends[$p])) {
      usort($ends[$p], fn($x, $y) => ($y[1] <=> $x[1]) ?: ($y[0] <=> $x[0]));
      foreach ($ends[$p] as $e) $out .= $e[2];
    }
    if (isset($starts[$p])) {
      usort($starts[$p], fn($x, $y) => ($y[1] <=> $x[1]) ?: ($x[0] <=> $y[0]));
      foreach ($starts[$p] as $e) $out .= $e[2];
    }
    $next = $pos[$n + 1] ?? null;
    if ($next !== null && $next > $p)
      $out .= htmlspecialchars(mb_convert_encoding(substr($u, $p * 2, ($next - $p) * 2), 'UTF-8', 'UTF-16LE'), ENT_NOQUOTES);
  }
  return $out;
}

/* ---------- فرگمنت ---------- */
function fragKind(string $text): ?string {
  $t = ltrim(norm($text), '/'); $t = preg_replace('/@.*$/', '', $t); $t = preg_replace('/^(قیمت|نرخ)\s+/u', '', $t);
  $map = [
    'stars'   => ['استارز', 'استار', 'stars', 'star'],
    'premium' => ['پریمیوم', 'پرمیوم', 'premium'],
    'nft'     => ['nft', 'nfts', 'انفتی', 'ان اف تی', 'گیفت', 'گیفت ها', 'gifts', 'gift'],
    'all'     => ['فرگمنت', 'fragment'],
  ];
  foreach ($map as $k => $words) if (in_array($t, $words, true)) return $k;
  return null;
}
function fragUrl(string $kind): string {
  return ['stars'=>'https://fragment.com/stars', 'premium'=>'https://fragment.com/premium', 'nft'=>'https://fragment.com/gifts'][$kind] ?? 'https://fragment.com';
}
/** نرخ دلار (تومان) و قیمت TON (دلار) */
function fragCtx(): array {
  $r = iranData()['price_dollar_rl']['p'] ?? null;
  $rate = $r ? ((float) str_replace(',', '', (string)$r)) / 10 : 0.0;
  $ton = (float) (cryptoData('the-open-network')['usd'] ?? 0);
  return [$rate, $ton];
}
/** یک قیمت دلاری را به سه خط تومان / دلار / TON تبدیل می‌کند */
function fragLines(float $usd, float $rate, float $ton): string {
  $o = '';
  if ($rate > 0) $o .= '💰 <b>' . n($usd * $rate) . "</b> تومان\n";
  $o .= '💲 <b>$' . n($usd, $usd < 1 ? 4 : 2) . "</b> دلار\n";
  if ($ton > 0) { $t = $usd / $ton; $o .= '💎 <b>' . n($t, $t < 1 ? 5 : 2) . '</b> TON'; }
  return rtrim($o);
}
function fragFooter(float $rate, float $ton): string {
  $o = "\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n";
  if ($rate > 0) $o .= '💵 دلار: ' . n($rate) . " تومان\n";
  if ($ton > 0)  $o .= '💎 TON: $' . n($ton, 3) . "\n";
  return $o . '🕒 ' . jdate() . "\n\n🤖 " . tt('brand');
}
function starsText(): string {
  [$rate, $ton] = fragCtx(); $u = (float) cfg()['frag']['star_usd'];
  $o = tt('stars_title') . "\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n<blockquote>✦ <b>هر ۱ استار</b>\n" . fragLines($u, $rate, $ton) . "</blockquote>\n\n🛍 <b>پکیج‌ها</b>\n<blockquote expandable>";
  foreach ([50, 100, 250, 500, 1000, 2500, 5000, 10000] as $q) {
    $usd = $q * $u;
    $o .= '▫️ <b>' . n((float)$q) . '</b> ⭐ ← ' . ($rate > 0 ? n($usd * $rate) . ' تومان' : '$' . n($usd, 2)) . ' · $' . n($usd, 2) . "\n";
  }
  return rtrim($o) . '</blockquote>' . fragFooter($rate, $ton);
}
function premiumText(): string {
  [$rate, $ton] = fragCtx(); $c = cfg()['frag']; $u = max(0.000001, (float)$c['star_usd']);
  $o = tt('premium_title') . "\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n";
  $best = null; $bestMo = 0;
  foreach ([3 => ['🥉', 'p3'], 6 => ['🥈', 'p6'], 12 => ['🥇', 'p12']] as $mo => [$badge, $key]) {
    $usd = (float)$c[$key]; $per = $usd / $mo;
    if ($best === null || $per < $best) { $best = $per; $bestMo = $mo; }
    $o .= "<blockquote>$badge <b>$mo ماهه</b>\n" . fragLines($usd, $rate, $ton) . "\n⭐ معادل ≈ " . n(round($usd / $u)) . " استار";
    if ($rate > 0) $o .= "\n📆 ماهانه ≈ " . n($per * $rate) . ' تومان';
    $o .= "</blockquote>\n";
  }
  if ($bestMo) $o .= "\n💡 مقرون‌به‌صرفه‌ترین: <b>$bestMo ماهه</b>";
  return $o . fragFooter($rate, $ton);
}
function nftText(): string {
  [$rate, $ton] = fragCtx(); $list = cfg()['frag']['nft'];
  $o = tt('nft_title') . "\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n";
  if (!$list) return $o . "هنوز NFT یا گیفتی ثبت نشده است.\n" . fragFooter($rate, $ton);
  foreach ($list as $x) {
    $tn = (float)$x['ton']; $usd = $ton > 0 ? $tn * $ton : 0.0;
    $o .= '<blockquote>🎁 <b>' . htmlspecialchars((string)$x['n']) . "</b>\n💎 <b>" . n($tn, 2) . '</b> TON';
    if ($usd > 0) $o .= "\n💲 <b>$" . n($usd, 2) . '</b> دلار';
    if ($usd > 0 && $rate > 0) $o .= "\n💰 <b>" . n($usd * $rate) . '</b> تومان';
    $o .= "</blockquote>\n";
  }
  return rtrim($o) . "\n" . fragFooter($rate, $ton);
}
function fragText(string $kind = 'all'): string {
  if ($kind === 'stars') return starsText();
  if ($kind === 'premium') return premiumText();
  if ($kind === 'nft') return nftText();
  [$rate, $ton] = fragCtx(); $c = cfg()['frag'];
  $o = tt('frag_title') . "\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n";
  $o .= '⭐ هر استار: <b>' . ($rate > 0 ? n((float)$c['star_usd'] * $rate) . ' تومان' : '$' . $c['star_usd']) . "</b>\n";
  foreach ([3 => 'p3', 6 => 'p6', 12 => 'p12'] as $mo => $key)
    $o .= "👑 پریمیوم $mo ماهه: <b>" . ($rate > 0 ? n((float)$c[$key] * $rate) . ' تومان' : '$' . $c[$key]) . "</b>\n";
  $o .= "\nبرای جزئیات بنویس: <code>استارز</code> ، <code>پریمیوم</code> ، <code>nft</code>";
  return $o . fragFooter($rate, $ton);
}

/* ---------- منوی دکمه‌ای کاربران ---------- */
function menuDefaults(): array {
  return [
    'me'     => ['label'=>'اطلاعات من',    'e'=>'👤', 'color'=>'primary'],
    'live'   => ['label'=>'بازار زنده',    'e'=>'🟢', 'color'=>'success'],
    'nft'    => ['label'=>'فلور گیفت‌ها',  'e'=>'🎁', 'color'=>'success'],
    'gold'   => ['label'=>'طلا و سکه',     'e'=>'🪙', 'color'=>'success'],
    'crypto' => ['label'=>'کریپتو',        'e'=>'📈', 'color'=>'success'],
    'cur'    => ['label'=>'ارز',           'e'=>'💵', 'color'=>'danger'],
    'help'   => ['label'=>'راهنما',        'e'=>'📚', 'color'=>'danger'],
    'calc'   => ['label'=>'ماشین‌حساب',    'e'=>'🧮', 'color'=>'primary'],
    'group'  => ['label'=>'افزودن به گروه','e'=>'➕', 'color'=>'primary'],
  ];
}
function menuCfg(): array {
  $d = menuDefaults(); $c = cfg()['menu'] ?? [];
  foreach ($d as $id => $v) $d[$id] = array_merge(['icon'=>'', 'on'=>true], $v, $c[$id] ?? []);
  return $d;
}
function menuHasIcons(): bool { foreach (menuCfg() as $m) if ((string)$m['icon'] !== '') return true; return false; }
function menuBtn(string $id, bool $icons): ?array {
  $m = menuCfg()[$id] ?? null; if (!$m || empty($m['on'])) return null;
  $all = btnColors(); $d = $all[$m['color']] ?? $all['default'];
  $pre = $d[2] !== '' ? $d[2] . ' ' : '';
  if ($icons && (string)$m['icon'] !== '') $b = ['text'=>$pre . $m['label'], 'icon_custom_emoji_id'=>(string)$m['icon']];
  else $b = ['text'=>$pre . ((string)$m['e'] !== '' ? $m['e'] . ' ' : '') . $m['label']];
  if ($d[1] !== '') $b['style'] = $d[1];
  switch ($id) {
    case 'live':  $b['web_app'] = ['url'=>appUrl()]; break;
    case 'calc':  $b['web_app'] = ['url'=>appUrl() . '?tab=calc']; break;
    case 'group': $b['url'] = 'https://t.me/' . BOT_USER . '?startgroup=true'; break;
    default:      $b['callback_data'] = 'm:' . $id;
  }
  return $b;
}
function menuKb(bool $icons = true): string {
  $rows = [];
  foreach ([['me'], ['live', 'nft'], ['gold', 'crypto'], ['cur', 'help'], ['calc'], ['group']] as $r) {
    $row = []; foreach ($r as $id) { $b = menuBtn($id, $icons); if ($b) $row[] = $b; }
    if ($row) $rows[] = $row;
  }
  $a = cfg()['ad'];
  if (!empty($a['on']) && (string)$a['btn_text'] !== '' && preg_match('#^(https?://|tg://)\S+$#', (string)$a['btn_url']))
    $rows[] = [mkBtn((string)$a['btn_text'], 'ad', ['url' => (string)$a['btn_url']])];
  return json_encode(['inline_keyboard' => $rows], JSON_UNESCAPED_UNICODE);
}
function backKb(): string {
  return json_encode(['inline_keyboard' => [
    [['text'=>'🔙 بازگشت', 'callback_data'=>'m:home', 'style'=>'danger']],
    [mkBtn(tt('btn_group'), 'group', ['url' => 'https://t.me/' . BOT_USER . '?startgroup=true'])],
  ]], JSON_UNESCAPED_UNICODE);
}
function menuText(array $from): string { return tt('menu_text', ['name'=>htmlspecialchars((string)($from['first_name'] ?? ''))]); }
function listText(string $title, array $keys): string {
  global $ITEMS; $o = $title . "\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n<blockquote>";
  foreach ($keys as $k) {
    if (!isset($ITEMS[$k])) continue; $it = $ITEMS[$k]; $p = getPrice($it, $k); if (!$p) continue;
    $v = isset($p['toman']) ? n($p['toman']) . ' تومان' : '$' . n($p['usd'], dec($p['usd']));
    $o .= $it['e'] . ' ' . $it['t'] . ': <b>' . $v . '</b>' . ($p['chg'] !== null ? ' ' . ($p['chg'] >= 0 ? '🟢+' : '🔴') . n($p['chg'], 2) . '%' : '') . "\n";
  }
  return rtrim($o) . "</blockquote>\n🕒 " . jdate() . "\n\n🤖 " . tt('brand');
}
function menuPage(string $act, array $from): string {
  switch ($act) {
    case 'me':
      return "👤 <b>اطلاعات من</b>\n┄┄┄┄┄┄┄┄┄┄┄┄┄┄\n\n<blockquote>🆔 آیدی عددی: <code>" . (int)($from['id'] ?? 0) . "</code>\n👤 نام: " . htmlspecialchars(trim(($from['first_name'] ?? '') . ' ' . ($from['last_name'] ?? '')))
        . "\n🔗 یوزرنیم: " . (!empty($from['username']) ? '@' . htmlspecialchars((string)$from['username']) : '—')
        . "\n⭐ پریمیوم تلگرام: " . (!empty($from['is_premium']) ? '✅ دارد' : '❌ ندارد')
        . "\n🌐 زبان: " . htmlspecialchars((string)($from['language_code'] ?? '—')) . "</blockquote>\n🕒 " . jdate() . "\n\n🤖 " . tt('brand');
    case 'nft':    return nftText();
    case 'gold':   return listText(tt('list_gold'), ['gold18', 'gold24', 'coin', 'sekeb', 'nim', 'rob', 'gerami', 'ons', 'silver']);
    case 'crypto': return listText(tt('list_crypto'), ['btc', 'eth', 'usdt', 'ton', 'sol', 'bnb', 'xrp', 'trx', 'doge', 'ada']);
    case 'cur':    return listText(tt('list_cur'), ['usd', 'eur', 'gbp', 'aed', 'try']) . "\n🌍 برای ارز کشورها بنویس: <code>ارزهای جهان</code>";
    case 'help':   return tt('help_text');
  }
  return menuText($from);
}
function sendMenu(int $chat, int $replyTo, array $from): void {
  $text = menuText($from);
  $try = function (bool $icons, bool $emo) use ($chat, $replyTo, $text) {
    return tg('sendMessage', ['chat_id'=>$chat, 'text'=>fin($text, true, $emo), 'parse_mode'=>'HTML', 'reply_to_message_id'=>$replyTo,
      'reply_markup'=>menuKb($icons), 'disable_web_page_preview'=>'true']);
  };
  $r = $try(true, true);
  if (empty($r['ok']) && (menuHasIcons() || cfg()['emoji'])) $try(false, false);   // اگر تلگرام آیکون/ایموجی پرمیوم را نپذیرفت
}
function handleMenuCb(array $cq, string $data): void {
  $act = substr($data, 2); $msg = $cq['message'] ?? null; $from = $cq['from'] ?? [];
  if ($msg) {
    $ids = ['chat_id'=>$msg['chat']['id'], 'message_id'=>$msg['message_id']];
    $text = $act === 'home' ? menuText($from) : menuPage($act, $from);
    $try = function (bool $icons, bool $emo) use ($ids, $text, $act) {
      return tg('editMessageText', $ids + ['text'=>fin($text, true, $emo), 'parse_mode'=>'HTML',
        'reply_markup'=>$act === 'home' ? menuKb($icons) : backKb(), 'disable_web_page_preview'=>'true']);
    };
    $r = $try(true, true);
    if (empty($r['ok']) && (menuHasIcons() || cfg()['emoji'])) $try(false, false);
  }
  tg('answerCallbackQuery', ['callback_query_id'=>$cq['id']]);
}

/* ---------- پنل ---------- */
function pb(string $t, string $d, string $style = ''): array { $b = ['text'=>$t, 'callback_data'=>$d]; if ($style !== '') $b['style'] = $style; return $b; }
function pkb(array $rows): string { return json_encode(['inline_keyboard'=>$rows], JSON_UNESCAPED_UNICODE); }

function panelHome(int $uid): array {
  $rows = [
    [pb('📢 تبلیغات', 'p:ad'), pb('🎨 رنگ دکمه‌ها', 'p:col')],
    [pb('🔤 فونت', 'p:font:0'), pb('✏️ ویرایش متن‌ها', 'p:txt')],
    [pb('✨ ایموجی پرمیوم', 'p:emo'), pb('💎 قیمت فرگمنت', 'p:frag')],
    [pb('🧭 منوی کاربران', 'p:menu'), pb('🧩 آیتم دلخواه', 'p:cus')],
    [pb('🏷 قیمت‌گذاری هوشمند', 'p:pr')],
  ];
  $last = [pb('📊 وضعیت', 'p:st')];
  if (isOwner($uid)) array_unshift($last, pb('👥 مدیران', 'p:adm'));
  $rows[] = $last; $rows[] = [pb('✖️ بستن', 'p:close')];
  return ["🛠 <b>پنل مدیریت</b>\n" . BRAND . "\n\nیک بخش را انتخاب کنید:", $rows];
}
function adScreen(): array {
  $a = cfg()['ad'];
  $t = "📢 <b>تبلیغات زیر ربات</b>\n\nوضعیت: " . (!empty($a['on']) ? '✅ روشن' : '⛔ خاموش')
     . "\n\nمتن:\n" . ((string)$a['text'] !== '' ? $a['text'] : '— خالی —')
     . "\n\nدکمه: " . ((string)$a['btn_text'] !== '' ? htmlspecialchars((string)$a['btn_text']) . ' ← ' . htmlspecialchars((string)$a['btn_url']) : '— ندارد —');
  return [$t, [
    [pb(!empty($a['on']) ? '⛔ خاموش کردن' : '✅ روشن کردن', 'p:ad_t', !empty($a['on']) ? 'danger' : 'success')],
    [pb('✏️ تنظیم متن', 'p:ad_txt'), pb('🔘 تنظیم دکمه', 'p:ad_btn')],
    [pb('🗑 پاک کردن همه', 'p:ad_clr', 'danger')],
    [pb('↩️ بازگشت', 'p:home')],
  ]];
}
function colScreen(): array {
  $c = cfg()['colors']; $all = btnColors();
  $names = ['refresh'=>'🔄 دکمه بروزرسانی', 'calc'=>'🧮 دکمه ماشین‌حساب', 'group'=>'➕ دکمه افزودن به گروه', 'ad'=>'📢 دکمه تبلیغ', 'sub'=>'🧭 دکمه‌های زیرمنو'];
  $rows = []; $t = "🎨 <b>رنگ دکمه‌ها</b>\n\nتلگرام فقط ۳ رنگ واقعی (آبی، سبز، قرمز) پشتیبانی می‌کند. بقیه رنگ‌ها با ایموجی رنگی کنار متن دکمه ساخته می‌شوند.\n\n";
  foreach ($names as $k => $label) {
    $t .= "$label: " . ($all[$c[$k] ?? 'default'][0] ?? '') . "\n";
    $rows[] = [pb($label, "p:colsel:$k")];
  }
  $rows[] = [pb('↩️ بازگشت', 'p:home')];
  return [$t, $rows];
}
function fontScreen(int $page): array {
  $st = fontStyles(); $keys = array_keys($st); $per = 8; $pages = (int) ceil(count($keys) / $per);
  $page = max(0, min($page, $pages - 1)); $cur = (string)cfg()['font'];
  $rows = []; $slice = array_slice($keys, $page * $per, $per);
  foreach (array_chunk($slice, 2) as $pair) {
    $r = [];
    foreach ($pair as $k) $r[] = pb(($k === $cur ? '✅ ' : '') . fontText('Gold 271', $k), "p:fontset:$k:$page");
    $rows[] = $r;
  }
  $nav = [];
  if ($page > 0) $nav[] = pb('◀️', 'p:font:' . ($page - 1));
  $nav[] = pb(($page + 1) . '/' . $pages, 'p:font:' . $page);
  if ($page < $pages - 1) $nav[] = pb('▶️', 'p:font:' . ($page + 1));
  $rows[] = $nav; $rows[] = [pb('↩️ بازگشت', 'p:home')];
  $t = "🔤 <b>فونت</b>\n\nفونت فعلی: <b>" . htmlspecialchars($st[$cur]['n'] ?? 'Normal') . "</b>\nنمونه: " . htmlspecialchars(fontText('Gold 271,010 USD', $cur))
     . "\n\nتلگرام اجازه تغییر فونت واقعی نمی‌دهد؛ این استایل‌ها فقط روی حروف لاتین و اعداد پیام‌ها اعمال می‌شوند (متن فارسی تغییری نمی‌کند).";
  return [$t, $rows];
}
function txtScreen(): array {
  $rows = []; foreach (textMeta() as $k => $m) $rows[] = [pb($m[0], "p:txte:$k")];
  $rows[] = [pb('↩️ بازگشت', 'p:home')];
  return ["✏️ <b>ویرایش متن‌های ربات</b>\n\nکدام متن را ویرایش می‌کنید؟", $rows];
}
function fragScreen(): array {
  $c = cfg()['frag'];
  $t = "💎 <b>قیمت‌های پایه فرگمنت</b> (دلار)\n\n⭐ هر استار: <b>\$" . $c['star_usd'] . "</b>\n👑 پریمیوم ۳ ماه: <b>\$" . $c['p3'] . "</b>\n👑 پریمیوم ۶ ماه: <b>\$" . $c['p6'] . "</b>\n👑 پریمیوم ۱۲ ماه: <b>\$" . $c['p12'] . "</b>\n\n🖼 NFTها: ";
  if ($c['nft']) { $t .= "\n"; foreach ($c['nft'] as $x) $t .= '• ' . htmlspecialchars((string)$x['n']) . ' — ' . $x['ton'] . " TON\n"; } else $t .= "— ندارد —\n";
  $t .= "\nعددهای پیش‌فرض تقریبی‌اند؛ با قیمت واقعی فرگمنت جایگزین کنید.";
  return [$t, [
    [pb('⭐ قیمت هر استار', 'p:frs:star_usd')],
    [pb('👑 ۳ ماه', 'p:frs:p3'), pb('👑 ۶ ماه', 'p:frs:p6'), pb('👑 ۱۲ ماه', 'p:frs:p12')],
    [pb('➕ افزودن NFT', 'p:frna'), pb('🗑 حذف NFT', 'p:frnd', 'danger')],
    [pb('↩️ بازگشت', 'p:home')],
  ]];
}
function cancelRow(): array { return [[pb('↩️ انصراف', 'p:cancel')]]; }

function panelRoute(string $d, int $uid): array {
  $a = explode(':', $d); $s = $a[0]; $c = cfg();
  if (strncmp($s, 'pr', 2) === 0) return prRoute($a, $uid);      // قیمت‌گذاری هوشمند (pricing.php)
  switch ($s) {
    case 'home': return panelHome($uid);
    case 'cancel': stClear($uid); return panelHome($uid);
    // تبلیغات
    case 'ad': return adScreen();
    case 'ad_t': $c['ad']['on'] = empty($c['ad']['on']); cfg($c); return adScreen();
    case 'ad_txt': stSet($uid, ['a'=>'ad_txt']); return ["📢 متن تبلیغ را بفرستید.\n\nمی‌توانید از قالب‌بندی تلگرام (بولد، لینک، ایموجی پرمیوم و ...) استفاده کنید. حداکثر ۴۰۰ کاراکتر.", cancelRow()];
    case 'ad_btn': stSet($uid, ['a'=>'ad_btn']); return ["🔘 دکمه تبلیغ را این‌طور بفرستید:\n<code>متن دکمه | https://لینک</code>", cancelRow()];
    case 'ad_clr': $c['ad'] = ['on'=>false, 'text'=>'', 'btn_text'=>'', 'btn_url'=>'']; cfg($c); return adScreen();
    // رنگ‌ها
    case 'col': return colScreen();
    case 'colsel':
      $t = $a[1] ?? 'refresh'; $rows = [];
      foreach (array_chunk(array_keys(btnColors()), 2) as $pair) {
        $r = []; foreach ($pair as $k) $r[] = pb(btnColors()[$k][0], "p:colset:$t:$k"); $rows[] = $r;
      }
      $rows[] = [pb('↩️ بازگشت', 'p:col')];
      return ["🎨 رنگ را انتخاب کنید:", $rows];
    case 'colset':
      $bc = btnColors();
      if (isset($c['colors'][$a[1] ?? ''], $bc[$a[2] ?? ''])) { $c['colors'][$a[1]] = $a[2]; cfg($c); }
      return colScreen();
    // فونت
    case 'font': return fontScreen((int)($a[1] ?? 0));
    case 'fontset':
      $fs = fontStyles();
      if (isset($fs[$a[1] ?? ''])) { $c['font'] = $a[1]; cfg($c); }
      return fontScreen((int)($a[2] ?? 0));
    // متن‌ها
    case 'txt': return txtScreen();
    case 'txte': case 'txtr':
      $k = $a[1] ?? ''; $meta = textMeta()[$k] ?? null; if (!$meta) return txtScreen();
      if ($s === 'txtr') { unset($c['texts'][$k]); cfg($c); }
      $cur = (string)(cfg()['texts'][$k] ?? textDefaults()[$k]);
      return ["✏️ <b>" . $meta[0] . "</b>\n\nمتن فعلی:\n<pre>" . htmlspecialchars($cur) . "</pre>" . ($meta[1] !== '' ? "\nمتغیرها: <code>" . htmlspecialchars($meta[1]) . "</code>" : ''), [
        [pb('✏️ ویرایش', "p:txts:$k"), pb('♻️ بازگشت به پیش‌فرض', "p:txtr:$k")],
        [pb('↩️ بازگشت', 'p:txt')],
      ]];
    case 'txts':
      $k = $a[1] ?? ''; $meta = textMeta()[$k] ?? null; if (!$meta) return txtScreen();
      stSet($uid, ['a'=>'txt', 'k'=>$k]);
      return ["✏️ متن جدید «" . $meta[0] . "» را بفرستید." . ($meta[2] ? "\n(فقط متن ساده، حداکثر ۴۰ کاراکتر)" : "\nمی‌توانید از قالب‌بندی تلگرام و ایموجی پرمیوم استفاده کنید.") . ($meta[1] !== '' ? "\nمتغیرها: <code>" . htmlspecialchars($meta[1]) . "</code>" : ''), cancelRow()];
    // ایموجی پرمیوم
    case 'emo': case 'emoc':
      if ($s === 'emoc') { $c['emoji'] = []; cfg($c); $c = cfg(); }
      $t = "✨ <b>ایموجی پرمیوم</b>\n\nتعداد ثبت‌شده: <b>" . count($c['emoji']) . "</b>\n" . implode(' ', array_slice(array_keys($c['emoji']), 0, 40))
         . "\n\nایموجی معمولی داخل پیام‌های ربات با نسخه پرمیوم جایگزین می‌شود.\n⚠️ تلگرام فقط به رباتی اجازه می‌دهد که صاحبش پریمیوم باشد یا یوزرنیم اضافه از فرگمنت خریده باشد؛ وگرنه ایموجی معمولی دیده می‌شود.";
      return [$t, [[pb('➕ ثبت ایموجی پرمیوم', 'p:emoa')], [pb('🗑 پاک کردن همه', 'p:emoc', 'danger')], [pb('↩️ بازگشت', 'p:home')]]];
    case 'emoa': stSet($uid, ['a'=>'emo']); return ["✨ یک پیام بفرستید که ایموجی‌های پرمیوم موردنظر داخلش باشد (چندتا هم می‌شود).", cancelRow()];
    // فرگمنت
    case 'frag': return fragScreen();
    case 'frs': $k = $a[1] ?? ''; if (!in_array($k, ['star_usd','p3','p6','p12'], true)) return fragScreen();
      stSet($uid, ['a'=>'fr', 'k'=>$k]); return ["عدد جدید را به دلار بفرستید (مثلا <code>0.016</code>):", cancelRow()];
    case 'frna': stSet($uid, ['a'=>'fr_nft']); return ["NFT را این‌طور بفرستید:\n<code>نام | قیمت به TON</code>\nمثلا: <code>Plush Pepe | 1200</code>", cancelRow()];
    case 'frnd':
      $rows = []; foreach ($c['frag']['nft'] as $i => $x) $rows[] = [pb('🗑 ' . mb_substr((string)$x['n'], 0, 24) . ' (' . $x['ton'] . ' TON)', "p:frndx:$i", 'danger')];
      $rows[] = [pb('↩️ بازگشت', 'p:frag')];
      return ["کدام NFT حذف شود؟", $rows];
    case 'frndx':
      $i = (int)($a[1] ?? -1); if (isset($c['frag']['nft'][$i])) { array_splice($c['frag']['nft'], $i, 1); cfg($c); }
      return fragScreen();
    // منوی کاربران
    case 'menu':
      $defs = menuDefs(); $mc = cfg()['menu']; $rows = [];
      foreach (array_chunk(array_keys($defs), 2) as $pair) {
        $r = []; foreach ($pair as $k) { $m = $mc[$k] ?? []; $r[] = pb(((isset($m['on']) && !$m['on']) ? '🚫 ' : '') . (string)($m['t'] ?? $defs[$k][0]), "p:mnu:$k"); }
        $rows[] = $r;
      }
      $rows[] = [pb('↩️ بازگشت', 'p:home')];
      return ["🧭 <b>منوی کاربران</b>\n\nدکمه‌هایی که بعد از /start در چت خصوصی دیده می‌شوند. روی هر دکمه بزنید تا متن، رنگ و ایموجی پرمیوم آن را تغییر دهید.", $rows];
    case 'mnu': case 'mnuo': case 'mnur': case 'mnud': case 'mnucs':
      $k = $a[1] ?? ''; $defs = menuDefs(); if (!isset($defs[$k])) return panelRoute('menu', $uid);
      if ($s === 'mnuo') { $c['menu'][$k]['on'] = isset($c['menu'][$k]['on']) ? !$c['menu'][$k]['on'] : false; cfg($c); }
      if ($s === 'mnur') { unset($c['menu'][$k]); cfg($c); }
      if ($s === 'mnud') { unset($c['menu'][$k]['icon']); cfg($c); }
      if ($s === 'mnucs') { $bc = btnColors(); if (isset($bc[$a[2] ?? ''])) { $c['menu'][$k]['c'] = $a[2]; cfg($c); } }
      $m = cfg()['menu'][$k] ?? []; $d = $defs[$k]; $bc = btnColors(); $on = !isset($m['on']) || $m['on'];
      $t = "🧭 <b>" . htmlspecialchars((string)($m['t'] ?? $d[0])) . "</b>\n\nوضعیت: " . ($on ? '✅ فعال' : '🚫 مخفی') . "\nرنگ: " . ($bc[(string)($m['c'] ?? $d[1])][0] ?? '') . "\nایموجی پرمیوم: " . (!empty($m['icon']) ? '✅ ثبت شده' : '— ندارد —')
         . "\n\nرنگ واقعی فقط آبی، سبز و قرمز است. آیکون پرمیوم فقط وقتی دیده می‌شود که صاحب ربات پریمیوم باشد یا یوزرنیم اضافه از فرگمنت خریده باشد.";
      return [$t, [
        [pb('✏️ متن دکمه', "p:mnut:$k"), pb('🎨 رنگ', "p:mnuc:$k")],
        [pb('✨ ایموجی پرمیوم', "p:mnui:$k"), pb('🗑 حذف ایموجی', "p:mnud:$k")],
        [pb($on ? '🚫 مخفی کردن' : '✅ نمایش', "p:mnuo:$k"), pb('♻️ پیش‌فرض', "p:mnur:$k")],
        [pb('↩️ بازگشت', 'p:menu')],
      ]];
    case 'mnuc':
      $k = $a[1] ?? ''; $rows = [];
      foreach (array_chunk(array_keys(btnColors()), 2) as $pair) { $r = []; foreach ($pair as $ck) $r[] = pb(btnColors()[$ck][0], "p:mnucs:$k:$ck"); $rows[] = $r; }
      $rows[] = [pb('↩️ بازگشت', "p:mnu:$k")];
      return ["🎨 رنگ دکمه را انتخاب کنید:", $rows];
    case 'mnut': $k = $a[1] ?? ''; stSet($uid, ['a'=>'mnu_t', 'k'=>$k]); return ["✏️ متن جدید دکمه را بفرستید (حداکثر ۳۰ کاراکتر، بدون ایموجی اگر آیکون پرمیوم می‌گذارید):", cancelRow()];
    case 'mnui': $k = $a[1] ?? ''; stSet($uid, ['a'=>'mnu_i', 'k'=>$k]); return ["✨ یک پیام بفرستید که فقط یک ایموجی پرمیوم داخلش باشد:", cancelRow()];
    // منوی کاربران
    case 'mn':
      $rows = []; foreach (menuCfg() as $id => $m) $rows[] = [pb((empty($m['on']) ? '⛔ ' : '✅ ') . $m['e'] . ' ' . $m['label'], "p:mne:$id")];
      $rows[] = [pb('↩️ بازگشت', 'p:home')];
      return ["🧭 <b>منوی کاربران</b>\n\nدکمه‌هایی که با /start در چت خصوصی دیده می‌شوند. هر دکمه را برای تغییر متن، رنگ و آیکون پرمیوم انتخاب کنید.\n(متن بالای منو و راهنما از «✏️ ویرایش متن‌ها» عوض می‌شود)", $rows];
    case 'mne': case 'mnt': case 'mncs': case 'mnx':
      $id = $a[1] ?? ''; $defs = menuDefaults(); if (!isset($defs[$id])) return panelRoute('mn', $uid);
      $c = cfg(); $bc = btnColors();
      if ($s === 'mnt') { $c['menu'][$id]['on'] = empty(menuCfg()[$id]['on']); cfg($c); }
      if ($s === 'mncs' && isset($bc[$a[2] ?? ''])) { $c['menu'][$id]['color'] = $a[2]; cfg($c); }
      if ($s === 'mnx') { $c['menu'][$id]['icon'] = ''; cfg($c); }
      $m = menuCfg()[$id];
      return ["🧭 <b>" . htmlspecialchars((string)$m['label']) . "</b>\n\nوضعیت: " . (!empty($m['on']) ? '✅ روشن' : '⛔ خاموش') . "\nرنگ: " . $bc[$m['color']][0]
        . "\nآیکون پرمیوم: " . ((string)$m['icon'] !== '' ? '✅ ثبت شده' : '— ندارد (ایموجی ' . $m['e'] . ' استفاده می‌شود) —')
        . "\n\n⚠️ آیکون پرمیوم فقط وقتی دیده می‌شود که صاحب ربات پریمیوم باشد یا یوزرنیم اضافه از فرگمنت خریده باشد.", [
        [pb('✏️ تغییر متن', "p:mnl:$id"), pb('🎨 رنگ', "p:mnc:$id")],
        [pb('✨ آیکون پرمیوم', "p:mni:$id"), pb('🧹 حذف آیکون', "p:mnx:$id")],
        [pb(!empty($m['on']) ? '⛔ خاموش کردن' : '✅ روشن کردن', "p:mnt:$id", !empty($m['on']) ? 'danger' : 'success')],
        [pb('↩️ بازگشت', 'p:mn')],
      ]];
    case 'mnc':
      $id = $a[1] ?? ''; $rows = [];
      foreach (array_chunk(array_keys(btnColors()), 2) as $pair) { $r = []; foreach ($pair as $k) $r[] = pb(btnColors()[$k][0], "p:mncs:$id:$k"); $rows[] = $r; }
      $rows[] = [pb('↩️ بازگشت', "p:mne:$id")];
      return ["🎨 رنگ دکمه را انتخاب کنید:", $rows];
    case 'mnl': case 'mni':
      $id = $a[1] ?? ''; $defs = menuDefaults(); if (!isset($defs[$id])) return panelRoute('mn', $uid);
      stSet($uid, ['a'=>$s === 'mnl' ? 'mn_label' : 'mn_icon', 'k'=>$id]);
      return [$s === 'mnl' ? "✏️ متن جدید دکمه را بفرستید (بدون ایموجی، حداکثر ۲۴ حرف):" : "✨ یک پیام بفرستید که فقط یک ایموجی پرمیوم داخلش باشد تا آیکون دکمه بشود:", cancelRow()];
    // آیتم‌های دلخواه
    case 'cus':
      $t = "🧩 <b>آیتم‌های دلخواه</b>\n\nهر قیمتی که tgju دارد (مثل مس، گاز، حواله دلار و ...) را با کلیدش اضافه کنید.\n\n";
      foreach ($c['custom'] as $x) $t .= '• ' . htmlspecialchars((string)$x['n']) . ' — <code>' . htmlspecialchars((string)$x['key']) . '</code> (' . $x['unit'] . ")\n";
      if (!$c['custom']) $t .= "— خالی —\n";
      return [$t, [[pb('➕ افزودن', 'p:cusa', 'success'), pb('🗑 حذف', 'p:cusd', 'danger')], [pb('↩️ بازگشت', 'p:home')]]];
    case 'cusa':
      stSet($uid, ['a'=>'cus']);
      return ["آیتم را این‌طور بفرستید:\n<code>نام | کلید tgju | rial یا usd</code>\nمثال: <code>مس | copper | usd</code>\n(کلید همان بخش آخر آدرس tgju.org/profile/... است یا از گزارش check پیدا می‌شود)", cancelRow()];
    case 'cusd':
      $rows = []; foreach ($c['custom'] as $i => $x) $rows[] = [pb('🗑 ' . mb_substr((string)$x['n'], 0, 24), "p:cusdx:$i", 'danger')];
      $rows[] = [pb('↩️ بازگشت', 'p:cus')];
      return ["کدام آیتم حذف شود؟", $rows];
    case 'cusdx':
      $i = (int)($a[1] ?? -1); if (isset($c['custom'][$i])) { array_splice($c['custom'], $i, 1); cfg($c); }
      return panelRoute('cus', $uid);
    // مدیران (فقط مالک)
    case 'adm': case 'admd': case 'adma':
      if (!isOwner($uid)) return panelHome($uid);
      if ($s === 'admd') { $c['admins'] = array_values(array_diff(array_map('intval', $c['admins']), [(int)($a[1] ?? 0)])); cfg($c); $c = cfg(); }
      if ($s === 'adma') { stSet($uid, ['a'=>'adm']); return ["👥 آیدی عددی ادمین جدید را بفرستید یا یک پیام از او فوروارد کنید.\n(او می‌تواند با دستور /id آیدی‌اش را از ربات بگیرد)", cancelRow()]; }
      $rows = []; foreach ($c['admins'] as $id) $rows[] = [pb('🗑 ' . $id, 'p:admd:' . $id, 'danger')];
      $rows[] = [pb('➕ افزودن ادمین', 'p:adma', 'success')]; $rows[] = [pb('↩️ بازگشت', 'p:home')];
      return ["👥 <b>مدیران</b>\n\n👑 مالک: <code>" . OWNER_ID . "</code>\nادمین‌ها: " . ($c['admins'] ? implode(' ، ', array_map('intval', $c['admins'])) : '— ندارد —') . (cfgAdmins() ? "\nادمین‌های config.php: " . implode(' ، ', cfgAdmins()) : ''), $rows];
    case 'st':
      $c = cfg();
      return ["📊 <b>وضعیت</b>\n\n👑 مالک: <code>" . OWNER_ID . "</code>\n👥 ادمین‌ها: " . count($c['admins']) . "\n📢 تبلیغ: " . (!empty($c['ad']['on']) ? 'روشن' : 'خاموش')
        . "\n🔤 فونت: " . htmlspecialchars(fontStyles()[$c['font']]['n'] ?? 'Normal') . "\n✨ ایموجی پرمیوم: " . count($c['emoji'])
        . "\n📈 چارت: " . CHART_STYLE . "\n🖼 NFTها: " . count($c['frag']['nft']), [[pb('↩️ بازگشت', 'p:home')]]];
  }
  return panelHome($uid);
}
function handlePanelCb(array $cq, string $data, int $uid, ?array $msg): void {
  if (!$msg || !isAdmin($uid)) { tg('answerCallbackQuery', ['callback_query_id'=>$cq['id'], 'text'=>'⛔ دسترسی ندارید', 'show_alert'=>'true']); return; }
  $d = substr($data, 2);
  $ids = ['chat_id'=>$msg['chat']['id'], 'message_id'=>$msg['message_id']];
  if ($d === 'close') { tg('deleteMessage', $ids); tg('answerCallbackQuery', ['callback_query_id'=>$cq['id']]); return; }
  [$text, $rows] = panelRoute($d, $uid);
  tg('editMessageText', $ids + ['text'=>$text, 'parse_mode'=>'HTML', 'reply_markup'=>pkb($rows), 'disable_web_page_preview'=>'true']);
  tg('answerCallbackQuery', ['callback_query_id'=>$cq['id']]);
}
/** ورودی متنی ادمین وقتی پنل منتظر پاسخ است. true = پیام مصرف شد */
function panelInput(array $m, array $st, int $uid): bool {
  $chat = $m['chat']['id']; $text = (string)($m['text'] ?? ''); $ents = $m['entities'] ?? [];
  $say = function (string $t, array $rows = []) use ($chat) {
    return tg('sendMessage', ['chat_id'=>$chat, 'text'=>$t, 'parse_mode'=>'HTML', 'reply_markup'=>pkb($rows ?: [[pb('🛠 پنل', 'p:home')]])]);
  };
  if (trim($text) === '/cancel') { stClear($uid); $say('انصراف داده شد.'); return true; }
  if (preg_match('#^/(panel|start|id)\b#', trim($text))) return false;          // دستورها عادی کار کنند
  $c = cfg(); $a = (string)($st['a'] ?? '');
  if (strncmp($a, 'pr_', 3) === 0) return prInput($m, $st, $uid);   // ورودی‌های قیمت‌گذاری هوشمند
  $valid = function (string $html) use ($chat): bool {
    $r = tg('sendMessage', ['chat_id'=>$chat, 'text'=>$html, 'parse_mode'=>'HTML']);   // این پیام همان پیش‌نمایش است
    return !empty($r['ok']);
  };
  switch ($a) {
    case 'ad_txt':
      $html = entHtml($text, $ents);
      if (trim($html) === '' || mb_strlen($html) > 400) { $say('متن خالی است یا از ۴۰۰ کاراکتر بیشتر است. دوباره بفرستید یا /cancel'); return true; }
      if (!$valid($html)) { $say('⚠️ متن نامعتبر است. دوباره بفرستید یا /cancel'); return true; }
      $c['ad']['text'] = $html; $c['ad']['on'] = true; cfg($c); stClear($uid);
      $say('✅ تبلیغ ذخیره و روشن شد.', [[pb('📢 تبلیغات', 'p:ad')]]); return true;
    case 'ad_btn':
      $p = array_map('trim', explode('|', $text, 2));
      if (count($p) < 2 || $p[0] === '' || mb_strlen($p[0]) > 40 || !preg_match('#^(https?://|tg://)\S+$#', $p[1])) { $say('فرمت درست نیست. مثال: <code>متن دکمه | https://t.me/example</code>'); return true; }
      $c['ad']['btn_text'] = $p[0]; $c['ad']['btn_url'] = $p[1]; cfg($c); stClear($uid);
      $say('✅ دکمه ذخیره شد.', [[pb('📢 تبلیغات', 'p:ad')]]); return true;
    case 'txt':
      $k = (string)($st['k'] ?? ''); $meta = textMeta()[$k] ?? null; if (!$meta) { stClear($uid); return true; }
      if ($meta[2]) {
        $v = trim($text);
        if ($v === '' || mb_strlen($v) > 40) { $say('متن خالی است یا از ۴۰ کاراکتر بیشتر است.'); return true; }
      } else {
        $v = entHtml($text, $ents);
        if (trim($v) === '') { $say('متن خالی است.'); return true; }
        if ($k === 'card_tpl' && strpos($v, '{lines}') === false) { $say('قالب باید حتما <code>{lines}</code> داشته باشد.'); return true; }
        if (!$valid($v)) { $say('⚠️ متن نامعتبر است. دوباره بفرستید یا /cancel'); return true; }
      }
      $c['texts'][$k] = $v; cfg($c); stClear($uid);
      $say('✅ ذخیره شد.', [[pb('✏️ متن‌ها', 'p:txt')]]); return true;
    case 'emo':
      $u = mb_convert_encoding($text, 'UTF-16LE', 'UTF-8'); $n = 0;
      foreach ($ents as $e) {
        if (($e['type'] ?? '') !== 'custom_emoji') continue;
        $ch = mb_convert_encoding(substr($u, (int)$e['offset'] * 2, (int)$e['length'] * 2), 'UTF-8', 'UTF-16LE');
        $c['emoji'][$ch] = (string)$e['custom_emoji_id'];
        $bare = str_replace("\u{FE0F}", '', $ch); if ($bare !== '' && $bare !== $ch) $c['emoji'][$bare] = (string)$e['custom_emoji_id'];
        $n++;
      }
      if ($n === 0) { $say('ایموجی پرمیوم پیدا نشد. ایموجی‌های پرمیوم را داخل پیام بفرستید یا /cancel'); return true; }
      cfg($c); stClear($uid); $say("✅ $n ایموجی پرمیوم ثبت شد.", [[pb('✨ ایموجی پرمیوم', 'p:emo')]]); return true;
    case 'fr':
      $k = (string)($st['k'] ?? ''); $v = (float) str_replace(',', '.', strtr(trim($text), ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']));
      if ($v <= 0) { $say('عدد معتبر بفرستید (مثلا 0.016)'); return true; }
      $c['frag'][$k] = $v; cfg($c); stClear($uid); $say('✅ ذخیره شد.', [[pb('💎 فرگمنت', 'p:frag')]]); return true;
    case 'fr_nft':
      $p = array_map('trim', explode('|', $text, 2)); $v = isset($p[1]) ? (float) str_replace(',', '', $p[1]) : 0.0;
      if (count($p) < 2 || $p[0] === '' || $v <= 0) { $say('فرمت: <code>نام | قیمت TON</code>'); return true; }
      $c['frag']['nft'][] = ['n'=>mb_substr($p[0], 0, 40), 'ton'=>$v]; cfg($c); stClear($uid);
      $say('✅ اضافه شد.', [[pb('💎 فرگمنت', 'p:frag')]]); return true;
    case 'mnu_t':
      $k = (string)($st['k'] ?? ''); $v = trim($text);
      if ($v === '' || mb_strlen($v) > 30 || !isset(menuDefs()[$k])) { $say('متن خالی است یا از ۳۰ کاراکتر بیشتر است.'); return true; }
      $c['menu'][$k]['t'] = $v; cfg($c); stClear($uid); $say('✅ ذخیره شد.', [[pb('🧭 دکمه', "p:mnu:$k")]]); return true;
    case 'mnu_i':
      $k = (string)($st['k'] ?? ''); $id = '';
      foreach ($ents as $e) if (($e['type'] ?? '') === 'custom_emoji') { $id = (string)$e['custom_emoji_id']; break; }
      if ($id === '' || !isset(menuDefs()[$k])) { $say('ایموجی پرمیوم پیدا نشد. دوباره بفرستید یا /cancel'); return true; }
      $c['menu'][$k]['icon'] = $id; cfg($c); stClear($uid); $say('✅ ایموجی ثبت شد.', [[pb('🧭 دکمه', "p:mnu:$k")]]); return true;
    case 'mn_label':
      $k = (string)($st['k'] ?? ''); $defs = menuDefaults(); $v = trim($text);
      if (!isset($defs[$k])) { stClear($uid); return true; }
      if ($v === '' || mb_strlen($v) > 24) { $say('متن خالی است یا از ۲۴ حرف بیشتر است.'); return true; }
      $c['menu'][$k]['label'] = $v; cfg($c); stClear($uid);
      $say('✅ ذخیره شد.', [[pb('🧭 دکمه', "p:mne:$k")]]); return true;
    case 'mn_icon':
      $k = (string)($st['k'] ?? ''); $defs = menuDefaults(); $id = '';
      foreach ($ents as $e) if (($e['type'] ?? '') === 'custom_emoji') { $id = (string)$e['custom_emoji_id']; break; }
      if (!isset($defs[$k])) { stClear($uid); return true; }
      if ($id === '') { $say('ایموجی پرمیوم پیدا نشد. یک ایموجی پرمیوم بفرستید یا /cancel'); return true; }
      $c['menu'][$k]['icon'] = $id; cfg($c); stClear($uid);
      $say('✅ آیکون پرمیوم ثبت شد.', [[pb('🧭 دکمه', "p:mne:$k")]]); return true;
    case 'cus':
      $p = array_map('trim', explode('|', $text)); $unit = strtolower($p[2] ?? 'rial'); $unit = ['ریال'=>'rial', 'دلار'=>'usd'][$unit] ?? $unit;
      if (count($p) < 2 || $p[0] === '' || !preg_match('/^[A-Za-z0-9_.\-]{2,50}$/', $p[1]) || !in_array($unit, ['rial', 'usd'], true)) { $say('فرمت: <code>نام | کلید | rial یا usd</code>'); return true; }
      $d = iranData();
      if (!$d || !isset($d[$p[1]])) {
        $sim = $d ? array_slice(array_filter(array_keys($d), fn($x) => stripos((string)$x, $p[1]) !== false), 0, 8) : [];
        $say('⚠️ این کلید در tgju پیدا نشد.' . ($sim ? "\nمشابه‌ها: <code>" . htmlspecialchars(implode('، ', $sim)) . '</code>' : '')); return true;
      }
      $c['custom'][] = ['n'=>mb_substr($p[0], 0, 40), 'key'=>$p[1], 'unit'=>$unit, 'e'=>'📌']; cfg($c); stClear($uid);
      $say('✅ اضافه شد. حالا کاربران می‌توانند «' . htmlspecialchars($p[0]) . '» را بنویسند.', [[pb('🧩 آیتم‌ها', 'p:cus')]]); return true;
    case 'adm':
      if (!isOwner($uid)) { stClear($uid); return true; }
      $id = (int)($m['forward_origin']['sender_user']['id'] ?? ($m['forward_from']['id'] ?? 0));
      if (!$id && preg_match('/^\d{5,15}$/', trim($text))) $id = (int)trim($text);
      if (!$id) { $say('آیدی عددی بفرستید یا پیام او را فوروارد کنید (اگر فوروارد او مخفی است، آیدی عددی بفرستید).'); return true; }
      if (!isOwner($id) && !in_array($id, array_map('intval', $c['admins']), true)) { $c['admins'][] = $id; cfg($c); }
      stClear($uid); $say("✅ ادمین <code>$id</code> اضافه شد.", [[pb('👥 مدیران', 'p:adm')]]); return true;
  }
  stClear($uid); return false;
}
