نصب / بروزرسانی (به ترتیب)
0) روی سرور اوبونتو: bash install.sh YOUR.DOMAIN you@email.com  (همه‌چیز را خودش نصب می‌کند)
1) ربات قبلاً کار می‌کرده؟  فقط این‌ها را روی همان فایل‌های قبلی کپی کن: bot.php  panel.php  pricing.php  calc.php
   config.php و menu.php و world.php و miniapp.html را دست نزن/پاک نکن (menu.php و world.php داخل این بسته نیستند).
2) config.php: توکن جدید (/revoke در BotFather)، SECRET، OWNER_ID و ADMIN_IDS را پر کن (نمونه: config.example.php).
3) health.php?key=SECRET را باز کن؛ همه‌ی خطوط باید OK باشند. بعدش health.php را پاک کن.
4) bot.php?setup=SECRET را باز کن؛ باید "ok":true ببینی.
5) کرون هر ۵ دقیقه:  curl -s "https://دامنه/bot.php?cron=SECRET"
6) در تلگرام: /panel  ←  🏷 قیمت‌گذاری هوشمند
فایل‌ها باید مستقیم داخل Document Root همین دامنه باشند، نه داخل یک پوشه‌ی اضافه.
